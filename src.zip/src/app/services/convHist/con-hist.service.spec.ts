import { TestBed } from '@angular/core/testing';

import { ConHistService } from './con-hist.service';

describe('ConHistService', () => {
  let service: ConHistService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConHistService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
