import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { chartResponses } from '../newChart/newchart.service';



export interface allConvRes{  
  id: number;  
  email_id: string;  
  conv_name: string;  
  pinned: boolean;  
}  

export interface docUpload{
  id:number;
  udoc_path: string;
  email_id:string
}


export interface getDocs{
  id:number;
  udoc_path:string;
  email_id:string;
}
@Injectable({
  providedIn: 'root'
})
export class ConHistService {

  constructor(private http: HttpClient) { }
  private apiUrl = 'https://informed-hardly-oyster.ngrok-free.app/';

  getAllConvs() 
  {
    const email_id = localStorage.getItem('userProfileName');
    const url = this.apiUrl+"allConv/"+email_id+"/" ;
    console.log("url: "+ url );
    return this.http.post<any>(url,{})
    
   
  }
  

  updateConvName(id:any, newName:any):void{
    const email_id = localStorage.getItem('userProfileName');
    const url = this.apiUrl+"updateconv/"+id ;
    const reqB = { 'conv_name': newName };
    console.log("Calling update conv name:   "+ id);
    
    this.http.post(url,reqB).subscribe(response =>{
      console.log(response);
      
    });
  }



  deleteConv(id:any){
    console.log("Conv id: "+ id);
    
    
    const url = this.apiUrl+"updateconv/"+ id
    return this.http.delete(url,{});
  }




  pinningConv(id:number, pinOrNot:any){
    console.log("Conv id: "+ id);
    console.log("Pinned or Not: "+ pinOrNot);
    
    
    
    const url = this.apiUrl+"/updateconv/"+ id
    return this.http.post(url,{"pinned":!pinOrNot})
  }





  uploadDoc(formData : FormData){
    const email_id = localStorage.getItem('userProfileName');

    const url = this.apiUrl+'rag/userUpload/cheerla.bhuvanesh@lwpcoe.com';
    return this.http.post<docUpload>(url,formData)
 
  }

  deleteDoc()
  {
    const email_id = localStorage.getItem('userProfileName');
    const docId = localStorage.getItem('docUploadedID');
    console.log("Doc Id:  "+docId);
    
    const url = this.apiUrl+'rag/userDelete/'+docId;
    this.http.post(url,{'email_id':email_id}).subscribe(response=>console.log("Deleted Doc: "+ response) )
    localStorage.setItem('docUploadedID','');
  }

retreiveConvById(convId:any){
  console.log("ConId: "+convId);
  
  const url = this.apiUrl+'conv/msgs/'+convId+"/";
  return this.http.post<chartResponses[]>(url,{});
 
}

retrieveDoc(){
  const email_id = localStorage.getItem('userProfileName');
  const url = this.apiUrl+"rag/getUserDocs/"
  return this.http.post<getDocs[]>(url,{"email_id":email_id});
}



feedbckLikeDislike(feedback:string, msgId : number){
  const url = this.apiUrl+"conv/msgs/update/"+msgId;
  this.http.post(url,{"feedback":feedback}).subscribe(response=> console.log("Modified feedback: "+ JSON.stringify(response))
  )
  
}


datapurge(){
  const email_id = localStorage.getItem('userProfileName');
const api = this.apiUrl+'rag/deleteSpecificUserDocs/'+email_id;
this.http.delete(api).subscribe(response=>{
  console.log("Data Purge: "+ response);
  
},
error => {
  alert("There is an issue with deleting your data. Please try later.")
})
}

}
