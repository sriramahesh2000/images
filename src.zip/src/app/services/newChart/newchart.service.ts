import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';


interface newChartResponse {
  username: string;
  chatId: number;
}


export interface Message {
  userReaction: string;
  content: string;
  timestamp: string;
  sender: 'bot' | 'user';
  id:string
}

interface newChartRes{
  'id':number;
  'email_id': string;
  'conv_name':string;


}

export interface chartResponses{
  'id':number ;
  'msg':string;
  'conv_id':number;
  'msg_type':string;
  'time':string;
  'feedback':  string;
  'response_from':string
}

@Injectable({
  providedIn: 'root'
})
export class NewchartService {

 
  safeUrl: SafeResourceUrl | null = null;  // profile!: ProfileType;
  constructor(private http: HttpClient,private sanitizer: DomSanitizer) { 

   
    
  }

  updateReactions(username: string, messageId: string, reaction: string): void {
    const requestBody = {
      username: username,
      messageId: messageId,
      reaction: reaction
    };
    return ;
    // this.http.post<any>(this.apiUrl, requestBody);
  }

  
  
  private apiUrl = 'https://informed-hardly-oyster.ngrok-free.app/';

  getNewChartId(): void {  
    const email_id = localStorage.getItem('userProfileName');  
    console.log("creating new convo id");  
    const reqB = { 'email_id': email_id };

    this.http.post<newChartRes>(this.apiUrl+'conv/', reqB).subscribe(  
      response => {  
        
        console.log('storing the new chart id.'+ response.id.toString());  
        localStorage.setItem('currentConvId', response.id.toString());  
      },  
      error => {  
        console.error('There was an error:', error);  
      }  
    );  


}


getConvoFromId(id:number):Observable<Array<chartResponses>>{
  const currChatId = localStorage.getItem('conversationId');
  console.log("Retrieving a particular convo");
  const url = 'http://localhost:8000/conv/msgs/'+currChatId;
  return this.http.get<Array<chartResponses>>(url);

}


likeOrDislike(feedback:string){
  const currChatId = localStorage.getItem('conversationId');
  const url = 'http://localhost:8000/conv/msgs/update/'+ currChatId;
  const reqB = { 'feedback': feedback };
  this.http.post(url,reqB).subscribe(
    response => console.log("Like or Dislike: "+ response)
    
  );

}
  getLLMResponse(){
    const email_id = localStorage.getItem('userProfileName');  
    
  }

  getStoredUsername(): string | null {
    return localStorage.getItem('username');
  }

  getStoredChartId(): number | null {
    const storedChartId = localStorage.getItem('newChartId');
    return storedChartId ? +storedChartId : null;
  }

  updateMessages(username: string, chartId: string, queryText: string): Observable<Message> {
    const requestBody = {
      username: username,
      chartId: chartId,
      queryText: queryText
    };
    return this.http.post<any>(this.apiUrl, requestBody).pipe(
      map(response => {
        const botResponse: Message = {
          content: response.textResponse,
          timestamp: new Date().toLocaleTimeString(),
          sender: 'bot',
          userReaction: '',
          id: ''
        };

        return botResponse;
      })
    ); 
   }


   llmRes(query:string){
    const storedChartId = localStorage.getItem('currentConvId');
    console.log("New chart ID: "+ storedChartId);
    const ragTOrF = localStorage.getItem("RAGFromDoc")
    const fileName = localStorage.getItem('fileName');
    if(ragTOrF=='True' && fileName){
        const url = this.apiUrl+"rag/userRagResponse/";
        return this.http.post<chartResponses>(url, {"query":query, "conv_id": Number(storedChartId), 'filename':fileName});
    }
    else{
      const url = this.apiUrl+"rag/response/";
      return this.http.post<chartResponses>(url, {"query":query, "conv_id": Number(storedChartId)});
        
    }
     }


   ragConv(){
    const url = this.apiUrl+"rag/response/";
    // this.http.post()
   }


}
