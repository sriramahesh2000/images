// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';



// export interface getSysPro{
//   id:number;
//   prompt:string
// }

// export interface getTemp{
//   id:number;
//   temperature:string;
// }


// export interface allLLMS{
//   id:number;
//   name: string;
//   endpoint: string;
//   key:string;
//   enabled:boolean
// }

// @Injectable({
//   providedIn: 'root'
// })

// export class AdminServiceService {

//   constructor(private http: HttpClient) { }
//   private apiUrl = 'https://informed-hardly-oyster.ngrok-free.app/';
//   retrieveSysPrompt(){
//     const url = this.apiUrl+"getPrompt/1";
//     return this.http.post<getSysPro>(url,{})
//   }

//   updateSysPrompt(updatedPrompt:string){
//     const url = this.apiUrl+"updatePrompt/1"
//     return this.http.post(url,{'prompt':updatedPrompt}).subscribe(
//       response => console.log("System Prompt Updated: "+ JSON.stringify(response))
      
//     )
//   }

//   getTemp(){
//     const url = this.apiUrl+"getTemp/1";
//     return this.http.post<getTemp>(url,{})
//   }

//   updateTemp(temp: any){
//     const url = this.apiUrl+"updateTemp/1";
//     return this.http.post(url,{'temperature':temp}).subscribe(
//       response=>console.log("Temperature updated: "+JSON.stringify(response))
      
//     )
//   }

//   getLLMList(){
//     const url = this.apiUrl+"llm/list/";
//     return this.http.post<allLLMS[]>(url,{})
//   }

//   enableDisableLLM(id: number, enable:boolean){
//     const url = this.apiUrl+"llm/update/"+id;
//     this.http.post(url,{"enabled": enable}).subscribe(response => console.log("Enable or disabled: "+  JSON.stringify(response))
//   )
//   }

//   removeLLM(id:number){
//     const url = this.apiUrl+'llm/delete/'+id;
//     this.http.delete(url).subscribe(response => console.log("LLL Removed  "+  JSON.stringify(response)))
//   }

//     getEnabledLLMS(){
//       const url = this.apiUrl+'llm/enabled/list/'
//       this.http.post<allLLMS[]>(url,{})
//     }

//     addLLM(name:string, endpoint:string, key:string){
//       const url = this.apiUrl+'addLLM/'
//       this.http.post(url,{"name":name,"endpoint":endpoint,"key":key}).subscribe(response=> console.log(response)
//       )

//     }

//     updateLLM(id: number,name:string, endpoint:string, key:string){
//       const url = this.apiUrl+'update/'+id
//       this.http.post(url,{"name":name,"endpoint":endpoint,"key":key}).subscribe(response => console.log("Updated LLM: "+JSON.stringify(response))
//       )

//     }
// }






import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

export interface getSysPro {
  id: number;
  prompt: string;
}

export interface getTemp {
  id: number;
  temperature: string;
}

export interface allLLMS {
  id: number;
  name: string;
  endpoint: string;
  key: string;
  enabled: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {
  private apiUrl = 'https://informed-hardly-oyster.ngrok-free.app/';

  constructor(private http: HttpClient) {}
  retrieveSysPrompt(){
    const url = this.apiUrl+"getPrompt/1";
    return this.http.post<getSysPro>(url,{})
  }

  updateSysPrompt(updatedPrompt:string){
    const url = this.apiUrl+"updatePrompt/1"
    return this.http.post(url,{'prompt':updatedPrompt}).subscribe(
      response => console.log("System Prompt Updated: "+ JSON.stringify(response))
      
    )
  }

  getTemp(){
        const url = this.apiUrl+"getTemp/1";
        return this.http.post<getTemp>(url,{})
      }

  updateTemp(temp: any){
        const url = this.apiUrl+"updateTemp/1";
        return this.http.post(url,{'temperature':temp}).subscribe(
          response=>console.log("Temperature updated: "+JSON.stringify(response))
          
        )
      }


  getLLMList() {
    const url = this.apiUrl + 'llm/list/';
    return this.http.post<allLLMS[]>(url, {});
  }

  getEnabledLLMS(){
    const url = this.apiUrl+"llm/enabled/list/"
    return this.http.post<any>(url,{})
  }

  enableDisableLLM(id: number, enable: boolean) {
    const url = this.apiUrl + 'llm/update/' + id;
    return this.http.post(url, { enabled: enable });
  }

  removeLLM(id: number) {
    const url = this.apiUrl + 'llm/delete/' + id;
    return this.http.delete(url);
  }

  addLLM(name: string, endpoint: string, key: string) {
    const url = this.apiUrl + 'addLLM/';
    return this.http.post(url, { name: name, endpoint: endpoint, key: key });
  }

  updateLLM(id: number, name: string, endpoint: string, key: string) {
    const url = this.apiUrl + 'llm/update/' + id;
    return this.http.post(url, { name: name, endpoint: endpoint, key: key });
  }

  addEdictword(word:any,meaning:any){
    const url = this.apiUrl+"addEnterpriseWord/"
   return  this.http.post(url,{"original_word": word,"enterprise_word":meaning})
    
  }

  removeDictWord(id: number){
    console.log(("Removing word id: "+id));
    
   const url = this.apiUrl+"deleteWord/"+id;
   return this.http.delete(url)
   
  }

  getAllWords(){
    const url = this.apiUrl+"getAllWords/";
    return this.http.post(url,{})
  }

}
