import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserUtils } from '@azure/msal-browser';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { MsalGuard } from '@azure/msal-angular';
import { LandingComponent } from './components/landing/landing.component';
import { LoginComponent } from './components/login/login.component';
import { NewchatComponent } from './components/newchat/newchat.component';
import { ConvHistComponent } from './components/conv-hist/conv-hist.component';
import { PinConvComponent } from './components/pin-conv/pin-conv.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { WorldviewComponent } from './components/worldview/worldview.component';
import { ControlsComponent } from './components/controls/controls.component';
import { ChatDocComponent } from './components/chat-doc/chat-doc.component';
import { LLMControlsComponent } from './components/llmcontrols/llmcontrols.component';
import { LLMFiltersComponent } from './components/llmfilters/llmfilters.component';
import { EDictComponent } from './components/edict/edict.component';
import { SystemPromptComponent } from './components/system-prompt/system-prompt.component';
import { TemperatureComponent } from './components/temperature/temperature.component';
import { DeleteUserDataComponent } from './components/delete-user-data/delete-user-data.component';


const routes: Routes = [
  {
    path: 'profile',
    component: ProfileComponent,
    canActivate: [MsalGuard],
  },
  {
    path: '',
    component: LoginComponent,
  },
  {
    path: 'home',
    component: HomeComponent,
  },
  {
    path:'landing',
    component:LandingComponent,
    children: [  
      { path: 'new-conversation', component: NewchatComponent },  
      { path: 'conversation-history', component: ConvHistComponent },  
      // { path: 'important-conversation', component: PinConvComponent }, 
      {path:'documentAI', component:ChatDocComponent}, 
      { path: 'dashboard', component: DashboardComponent },  
      { path: 'worldview', component: WorldviewComponent }, 
      {path: 'dataPurge', component:DeleteUserDataComponent},
      {path: 'profile', component: ProfileComponent},
      {path:'controls',component:ControlsComponent,
        children:[
          {path:'systemprompt', component:SystemPromptComponent},
          {path:'temperature',component:TemperatureComponent},
          {path:'llmControl', component:LLMControlsComponent},
          {path:'contentFilter', component:LLMFiltersComponent},
          {path:'enterpriseDict', component:EDictComponent},
          {path: '', redirectTo: 'systemprompt', pathMatch: 'full'}
        ]
      }, 
     
      {path:'genaiControl', component:LLMControlsComponent},
     
      {path:'contentFilters',component:LLMFiltersComponent},
      {path:'enterpriseDictionary', component:EDictComponent},
      {path:'systemPrompt', component:SystemPromptComponent},
      { path: '', redirectTo: 'new-conversation', pathMatch: 'full' },  // Redirect to 'dashboard' by default  
    ],
    // children:[{}],
    canActivate:[MsalGuard]
  },
  {
    // Needed for Error routing
    path: 'error',
    component: HomeComponent,
  },
  {
    // Needed for Error routing
    path: '**',
    component: LandingComponent,
    canActivate:[MsalGuard]
  },
  // {
  //   path:'/logout',
  //   redirectTo:'http://localhost:4200',
  // }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      onSameUrlNavigation: 'reload',
      // Don't perform initial navigation in iframes or popups
      initialNavigation:
        !BrowserUtils.isInIframe() && !BrowserUtils.isInPopup()
          ? 'enabledNonBlocking'
          : 'disabled', // Set to enabledBlocking to use Angular Universal
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
