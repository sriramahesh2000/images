import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as am4core from "@amcharts/amcharts4/core";  
import * as am4charts from "@amcharts/amcharts4/charts";  
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';
am4core.useTheme(am4themes_animated);  

type ProfileType = {

  givenName?: string,
  surname?: string,
  userPrincipalName?: string,
  id?: string
}

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profile!: ProfileType;
imageUrl: string = '/Users/CH20423189/Downloads/EnterpriseGPT-29thMayeve 2/src/assets/profileIcon.png';

  constructor(
    private http: HttpClient
  ) { }




  ngOnInit() {
    this.getProfile();
    let chartPie = am4core.create("chartdivPie", am4charts.PieChart);
    // chartPie.percentWidth = 100; 
    chartPie.width = am4core.percent(100);
    chartPie.paddingBottom = 25;
    // chartPie.paddingLeft = 100
    let title4 = chartPie.titles.create();
    title4.text = "Analysis";
    title4.fontSize = 17;
    title4.fontWeight = "bold";
    title4.paddingTop=7
    chartPie.data = [  
      { responseType: "Total Convo", counts: 386 },  
      { responseType: "Pinned Convo", counts: 25 },
      { responseType: "Models Used", counts: 308 },
      // { responseType: "Failed", counts: 81 }
     
    ]; 
    let pieSeries = chartPie.series.push(new am4charts.PieSeries());  
      pieSeries.dataFields.value = "counts";  
      pieSeries.dataFields.category = "responseType"; 
    
      chartPie.logo.disabled = true;
      chartPie.legend = new am4charts.Legend();

      let title = chartPie.titles.create();  
 
title.marginTop = 8; 
  }

  getProfile() {
    this.http.get(GRAPH_ENDPOINT)
      .subscribe(profile => {
        this.profile = profile;
      });
  }
}
