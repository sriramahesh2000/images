import { HttpClient } from '@angular/common/http';
import { Component, Input, SimpleChanges, ViewChild, ElementRef, AfterViewInit, HostListener, OnDestroy, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/services/admin/admin-service.service';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';
import { NewchartService, chartResponses } from 'src/app/services/newChart/newchart.service';

// interface UserProfile {
//   "@odata.context": string;
//   businessPhones: string[];
//   displayName: string;
//   givenName: string;
//   jobTitle: string | null;
//   id: string;
//   mail: string | null;
//   mobilePhone: string | null;
//   officeLocation: string | null;
//   preferredLanguage: string | null;
//   surname: string;
//   userPrincipalName: string;
// }

@Component({
  selector: 'app-chat-hist-conv',
  templateUrl: './chat-hist-conv.component.html',
  styleUrls: ['./chat-hist-conv.component.css']
})
export class ChatHistConvComponent implements AfterViewInit, OnInit {
  modelName: any = '';
  showDropup: boolean = false;
  firstModel: any;
  enabledLLMs: any[] = [];

modifyDay(dateTimeString: string) {
  let date = new Date(dateTimeString);

  let shortDate = date.toLocaleDateString();
  let shortTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return "Date Time: "+shortDate+" at "+shortTime;
  
}



  ngOnInit(): void {
    this.getEnabledLLM();
  }










   
  @ViewChild('chatContainer') chatContainer !: ElementRef;    
  @ViewChild('inputArea') inputArea !: ElementRef;    
  @Input()
  conversationId!: number;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['conversationId']) {
     
      localStorage.setItem('currentConvId',this.conversationId.toString());
      console.log('Selected conversation ID: from convhistchat', this.conversationId);

      this.conhistService.retreiveConvById(this.conversationId)
      .subscribe(
        response => {
          console.log(JSON.stringify(response))
        
          this.messages = response;

        }

      
      )
      setTimeout(() => this.scrollToBottom());

     
    }
   
    }
  constructor(private newchartService: NewchartService, private conhistService: ConHistService,private adminServiceService: AdminServiceService){}
  messages: chartResponses[]   = [] 
  isLoading: boolean = false
  ngAfterViewInit() {      
    this.scrollToBottom();      
  }      
  
  addMessage(message: string, sender: 'User' | 'bot'|'user') {    
    const convIdString = localStorage.getItem('conversationId');
    const convId = convIdString ? parseInt(convIdString, 10) : 9999;
    const newMessage: chartResponses = {
      msg: message,
      time: new Date().toLocaleTimeString(),
      msg_type: sender,
      id: 9999999,
      feedback:'',
      conv_id: convId,
      response_from:'User'
    };    
    this.messages.push(newMessage);    
    setTimeout(() => this.scrollToBottom());      
  }    
  
  sendMessage() {
    const message = this.inputArea.nativeElement.value.trim();
    this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);

    if (message !== '') {
      this.addMessage(message, 'User');
      this.inputArea.nativeElement.value = '';
    }

    this.isLoading = true; 

    setTimeout(() => this.scrollToBottom());

    this.newchartService.llmRes(message).subscribe(
      response => {
        console.log(response);
        const newMessage: chartResponses = {
          msg: response.msg,
          time: response.time,
          msg_type: response.msg_type,
          id: response.id,
          feedback: response.feedback,
          conv_id: response.conv_id,
          response_from: response.response_from
        };
        this.messages.push(newMessage);
        this.isLoading = false; 
        setTimeout(() => this.scrollToBottom());
      },
      error => {
        this.isLoading = false; 
        const newMessage: chartResponses = {
          msg: "Oops, something went wrong",
          time: new Date().toLocaleTimeString(),
          msg_type: "assistant",
          id: 999999,
          feedback: 'neutral',
          conv_id: 999999999,
          response_from: "From Backend"
        };
        this.messages.push(newMessage);
        setTimeout(() => this.scrollToBottom());
      },
      () => {
        this.inputArea      .nativeElement.addEventListener('keypress', this.onKeyPress);
      }
    );

    setTimeout(() => this.scrollToBottom());
  }

 
  onKeyPress(event: KeyboardEvent) {    
    if (event.key === 'Enter' && this.isLoading) {    
        event.preventDefault();
    } else if (event.key === 'Enter') {
        this.sendMessage(); // Optionally, you can call sendMessage() here to send the message when Enter is pressed.
    }    
  }
     
  
  scrollToBottom() {      
    if (this.chatContainer && this.chatContainer.nativeElement) {      
      this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;      
    }      
  }    
  

  likeMessage(event: MouseEvent,message: chartResponses) {
    const icon = event.target as HTMLElement;
    icon.classList.add('icon-clicked');
    setTimeout(() => {
      icon.classList.remove('icon-clicked');
    }, 300);
    if (message.feedback === 'liked') {
      message.feedback = '';
      this.conhistService.feedbckLikeDislike("neutral", message.id);
    } else {
      message.feedback = 'liked';
      this.conhistService.feedbckLikeDislike("liked", message.id);
    }
  }

  dislikeMessage(event: MouseEvent,message: chartResponses) {
    const icon = event.target as HTMLElement;
    icon.classList.add('icon-clicked');
    setTimeout(() => {
      icon.classList.remove('icon-clicked');
    }, 300);
    if (message.feedback === 'disliked') {
      message.feedback = '';
      this.conhistService.feedbckLikeDislike("neutral", message.id);
    } else {
      message.feedback = 'disliked';
      this.conhistService.feedbckLikeDislike("disliked", message.id);
    }
  }

   
  
  
  getEnabledLLM() {
    this.adminServiceService.getEnabledLLMS().subscribe(
      response => {
        this.enabledLLMs = response;  
        this.firstModel = response[0].name;  
        console.log("******** Enabled LLMs: ************** " + JSON.stringify(response) + response[0].name);  
      },
      error => console.log(error),
      () => {
        console.log("*********** First Model Name: ****** " + JSON.stringify(this.enabledLLMs[0]));
        const modelId = this.enabledLLMs[0].id;
        this.modelName = this.enabledLLMs[0].name;

        const lsSelectedModel = localStorage.getItem('selectedModel');
        console.log("Already Selected model: " + lsSelectedModel);

        if (lsSelectedModel != null && lsSelectedModel !== '') {
          this.modelName = lsSelectedModel;
        } else {
          this.modelName = this.enabledLLMs[0].name;
        }
      }
    );  
  }

  
     
  
  copyMessage(event: MouseEvent,message: chartResponses) {
    const icon = event.target as HTMLElement; 
    icon.classList.add('icon-clicked');
    setTimeout(() => {
      icon.classList.remove('icon-clicked');
    }, 300);
    console.log(message.msg)   
    navigator.clipboard.writeText(message.msg);   
       
  }   
  
  
  toggleDropup() {
    console.log("Toggling");
    this.showDropup = !this.showDropup;
  }

  selectModel(event: any) {
    const selectedEndpoint = event.target.value;
    localStorage.setItem('selectedModel', selectedEndpoint);
    this.modelName = selectedEndpoint;
    console.log("Selected Model: " + this.modelName);
  }

  @HostListener('document:click', ['$event'])
  onClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (!target.closest('.dropup')) {
      this.showDropup = false;
    }
  }


  
splitMessage(message: string): Array<{ type: 'text' | 'code', content: string, language?: string }> {
  const segments: Array<{ type: 'text' | 'code', content: string, language?: string }> = [];
  const parts = message.split(/(```[\s\S]*?```)/); // Split message by code blocks

  parts.forEach(part => {
      if (part.startsWith('```') && part.endsWith('```')) {
          const codeContent = part.substring(3, part.length - 3).trim();
          const firstLineEndIndex = codeContent.indexOf('\n');
          let language = 'code';
          let content = codeContent;

          if (firstLineEndIndex !== -1) {
              const firstLine = codeContent.substring(0, firstLineEndIndex).trim();
              const remainingContent = codeContent.substring(firstLineEndIndex + 1).trim();

              if (firstLine.match(/^[a-zA-Z0-9]+$/)) {
                  language = firstLine;
                  content = remainingContent;
              }
          }

          segments.push({ type: 'code', content, language });
      } else {
          segments.push({ type: 'text', content: part.trim() });
      }
  });

  return segments;
}


}   

