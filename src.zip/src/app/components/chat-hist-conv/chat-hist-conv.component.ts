import { Component, ElementRef, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';
import { NewchartService, chartResponses } from 'src/app/services/newChart/newchart.service';

@Component({
  selector: 'app-chat-hist-conv',
  templateUrl: './chat-hist-conv.component.html',
  styleUrls: ['./chat-hist-conv.component.css']
})
export class ChatHistConvComponent implements OnInit {
modifyDay(dateTimeString: string) {
  let date = new Date(dateTimeString);

  let shortDate = date.toLocaleDateString();
  let shortTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return "Date Time: "+shortDate+" at "+shortTime;
  
}


enabledLLMs: any[] = [];
  ngOnInit(): void {
  }
  showDropup: boolean = false;
  modelName: any = "GPT-3.5";


  toggleDropup() {
    console.log("Toggling");
    this.showDropup = !this.showDropup;
  }



  selectModel(event: any) {
    const selectedEndpoint = event.target.value;
    localStorage.setItem('selectedModel', selectedEndpoint);
    this.modelName = localStorage.getItem('selectedModel');
    localStorage.setItem('selectedModel', event.target.textContent.trim());

  }






   
  @ViewChild('chatContainer') chatContainer !: ElementRef;    
  @ViewChild('inputArea') inputArea !: ElementRef;    
  @Input()
  conversationId!: number;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['conversationId']) {
     
      localStorage.setItem('currentConvId',this.conversationId.toString());
      console.log('Selected conversation ID: from convhistchat', this.conversationId);

      this.conhistService.retreiveConvById(this.conversationId)
      .subscribe(
        response => {
          console.log(JSON.stringify(response))
        
          this.messages = response;

        }
      
      )

      
    }
  }
  constructor(private newchartService: NewchartService, private conhistService: ConHistService){}
  messages: chartResponses[]   = [] 
  isLoading: boolean = false
  ngAfterViewInit() {      
    this.scrollToBottom();      
  }      
  
  addMessage(message: string, sender: 'User' | 'bot'|'user') {    
    const convIdString = localStorage.getItem('conversationId');
    const convId = convIdString ? parseInt(convIdString, 10) : 9999;
    const newMessage: chartResponses = {
      msg: message,
      time: new Date().toLocaleTimeString(),
      msg_type: sender,
      id: 9999999,
      feedback:'',
      conv_id: convId,
      response_from:'User'
    };    
    this.messages.push(newMessage);    
    setTimeout(() => this.scrollToBottom());      
  }    
  
  sendMessage() {    
    const message = this.inputArea.nativeElement.value.trim();    
    if (message !== '') {    
      this.addMessage(message, 'user');    
      this.inputArea.nativeElement.value = '';    
    }    
    console.log("Seting isloading to true");
    
    this.isLoading=true;
    this.newchartService.llmRes(message).subscribe(response => {
      console.log(response)
      const newMessage: chartResponses = {
        msg: response.msg,
        time: response.time,
        msg_type: response.msg_type,
        id: response.id,
        feedback:response.feedback,
        conv_id: response.conv_id,
        response_from:response.response_from
      };  
      this.messages.push(newMessage);   
      this.isLoading=false; 
    },error =>{
      this.isLoading = false;    
      const newMessage: chartResponses = {
        msg: "Oops, something went wrong",
        time: new Date().toLocaleTimeString(),
        msg_type: "assistant",
        id: 999999,
        feedback:'neutral',
        conv_id: 999999999,
        response_from:"From frontend"
        
        
      };
      this.messages.push(newMessage);    
    }
     
    )
    this.scrollToBottom();    
  }    
  
  onKeyPress(event: KeyboardEvent) {    
    if (event.key === 'Enter' && this.isLoading) {    
        event.preventDefault();
    } else if (event.key === 'Enter') {
        this.sendMessage(); // Optionally, you can call sendMessage() here to send the message when Enter is pressed.
    }    
  }
     
  
  scrollToBottom() {      
    if (this.chatContainer && this.chatContainer.nativeElement) {      
      this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;      
    }      
  }    
  
  likeMessage(message: chartResponses) {      
    if (message.feedback === 'liked') {      
      message.feedback = '';   
      this.conhistService.feedbckLikeDislike("neutral", message.id)   
    } else {      
      message.feedback = 'liked';  
      this.conhistService.feedbckLikeDislike("liked", message.id)    
    }      
   
  }      
  
  dislikeMessage(message: chartResponses) { 
    console.log('disliked')        
    if (message.feedback === 'disliked') {      
      message.feedback = ''; 
      this.conhistService.feedbckLikeDislike("neutral", message.id)  
    } else {      
      message.feedback = 'disliked';   
     
      this.conhistService.feedbckLikeDislike("disliked", message.id)     
    }   
    
  }      
  
  copyMessage(event: MouseEvent,message: chartResponses) {
    const icon = event.target as HTMLElement; 
    icon.classList.add('icon-clicked');
    setTimeout(() => {
      icon.classList.remove('icon-clicked');
    }, 300);
    console.log(message.msg)   
    navigator.clipboard.writeText(message.msg);   
       
  }       
}   

