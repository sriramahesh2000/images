import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatHistConvComponent } from './chat-hist-conv.component';

describe('ChatHistConvComponent', () => {
  let component: ChatHistConvComponent;
  let fixture: ComponentFixture<ChatHistConvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChatHistConvComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChatHistConvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
