import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/services/admin/admin-service.service';

@Component({
  selector: 'app-temperature',
  templateUrl: './temperature.component.html',
  styleUrls: ['./temperature.component.css']
})
export class TemperatureComponent implements OnInit {

  constructor(private adminService : AdminServiceService) { }

  ngOnInit(): void {
    this.adminService.getTemp().subscribe(
      response => this.temperature = +response.temperature
    )
  }
  temperature!: number;
  submittedTemperature: number | null = null;

  onTemperatureChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.temperature = parseFloat(input.value);
  }

  submitTemperature(): void {
    this.submittedTemperature = this.temperature;
    const increment = 0.1;
  const roundedValue = Math.round(this.temperature / increment) * increment;
  const finalRoundedValue = Math.min(Math.max(roundedValue, 0.1), 1);
    console.log("Temp cud: "+finalRoundedValue);
    
    this.adminService.updateTemp(finalRoundedValue)
  }

}
