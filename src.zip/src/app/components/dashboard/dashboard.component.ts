import { Component, NgZone, OnInit } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";  
import * as am4charts from "@amcharts/amcharts4/charts";  
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import {  FormBuilder } from '@angular/forms';  
// import { Subscription } from 'rxjs';
import {FormControl} from '@angular/forms';  

am4core.useTheme(am4themes_animated);  
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

range = new FormControl();  
 
 
  private chart1: am4charts.XYChart | undefined;  
  private chart2: am4charts.XYChart | undefined; 
  
  constructor(private zone: NgZone, private fb: FormBuilder) { }

  ngOnInit(): void { 
    
   
    // this.dateRangeForm = this.fb.group({  
    //   date: [null]  
    // });  
   
    
    let chart = am4core.create("chartdiv", am4charts.XYChart); 
    const lastThreeMonths = this.getLastThreeMonths();
    console.log("Last three months: "+ lastThreeMonths);
     
  
    chart.data = this.generateChartData()
    // [  
    //     { month: "January", gpt4: 23, gemini: 18, cohere: 15 },  
    //     { month: "February", gpt4: 25, gemini: 20, cohere: 18 },  
    //     // add more data  
    // ];  
  
    let title1 = chart.titles.create();
    title1.text="Gen AI models Usage";
    title1.paddingBottom=12
    title1.fontSize = 17; // Adjust the font size as needed
    title1.fontWeight = "bold";
    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());  
    categoryAxis.dataFields.category = "month";  
    // chart.titles.create().text = "Gen AI models Comparsion";  
    categoryAxis.title.text = "Months"; 
    // categoryAxis.title.text = "Months"; 
    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());  
    // valueAxis.stackType = "100%";  //this line makes the chart "stacked"  
    valueAxis.title.text = "No.of Users"; 
    let series1 = chart.series.push(new am4charts.ColumnSeries());  
    series1.dataFields.valueY = "gpt4";  
    series1.dataFields.categoryX = "month";  
    series1.name = "GPT-4";  
    // series1.stacked = true;
  
    let series2 = chart.series.push(new am4charts.ColumnSeries());  
    series2.dataFields.valueY = "gemini";  
    series2.dataFields.categoryX = "month";  
    series2.name = "GPT-3.5"; 
    // series2.stacked = true; 
  
    let series3 = chart.series.push(new am4charts.ColumnSeries());  
    series3.dataFields.valueY = "cohere";  
    series3.dataFields.categoryX = "month";  
    series3.name = "GPT-4o";
    // series3.stacked = true;  
    chart.logo.disabled = true;
    chart.legend = new am4charts.Legend();  


    let chartPie = am4core.create("chartdivPie", am4charts.PieChart);
    // chartPie.percentWidth = 100; 
    chartPie.width = am4core.percent(100);
    chartPie.paddingBottom = 25;
    
    let title4 = chartPie.titles.create();
    title4.text = "User Feedback";
    title4.fontSize = 17;
    title4.fontWeight = "bold";
    title4.paddingTop=7
    chartPie.data = [  
      { responseType: "Positive", counts: 386 },  
      { responseType: "Negative", counts: 25 },
      { responseType: "Neutral", counts: 308 },
      // { responseType: "Failed", counts: 81 }
     
    ]; 
    let pieSeries = chartPie.series.push(new am4charts.PieSeries());  
      pieSeries.dataFields.value = "counts";  
      pieSeries.dataFields.category = "responseType"; 
    
      chartPie.logo.disabled = true;
      chartPie.legend = new am4charts.Legend();

      let title = chartPie.titles.create();  
 
title.marginTop = 8; 

}  

ngAfterViewInit() {  
  this.zone.runOutsideAngular(() => {  
  
  //   let dayWiseUsageTrend = [
  //     { month: new Date(2024, 4, 1), usage: 1000 },
  //     { month: new Date(2024, 4, 2), usage: 1200 },
  //     { month: new Date(2024, 4, 3), usage: 1100 },
  //     { month: new Date(2024, 4, 4), usage: 1300 },
  //     { month: new Date(2024, 4, 5), usage: 1200 },
  //     { month: new Date(2024, 4, 6), usage: 1400 },
  //     { month: new Date(2024, 4, 7), usage: 1400 },
  //     { month: new Date(2024, 4, 8), usage: 1800 },
  // ];
      


  let today = new Date();
  let currentYear = today.getFullYear();
  let currentMonth = today.getMonth(); // months are zero-indexed in JavaScript
  let dayWiseUsageTrend = [];
  
  for (let day = 1; day <= today.getDate(); day++) {
      let usage = 1000 + Math.floor(Math.random() * 1000); // generate random usage between 1000 and 1999
      dayWiseUsageTrend.push({ month: new Date(currentYear, currentMonth, day), usage: usage });
  }
  
  console.log(dayWiseUsageTrend);
  


    let mobileData = [  
      { month: new Date(2024, 0, 1), usage: 8000 },  
      { month: new Date(2024, 1, 1), usage: 900 },  
      { month: new Date(2024, 2, 1), usage: 8500 },  
      { month: new Date(2024, 3, 1), usage: 900 },  
      { month: new Date(2024, 4, 1), usage: 9000 },  
      { month: new Date(2024, 5, 1), usage: 10000 },  
    ];  
     

    // Create first line chart (Webapp usage over months)  
    let chart1 = am4core.create("chartdiv1", am4charts.XYChart);  
    chart1.data = dayWiseUsageTrend; 
    // chart1.titles.create().text = "E-GPT Usage Trend"; 
    let title = chart1.titles.create();
    title.text="E-GPT Usage Trend";
    title.fontSize = 17; // Adjust the font size as needed
    title.fontWeight = "bold";
    // title.paddingBottom=25

    let dateAxis1 = chart1.xAxes.push(new am4charts.DateAxis());  
    dateAxis1.dataFields.date = "month";  
    dateAxis1.title.text = "June Month"; 
    let valueAxis1 = chart1.yAxes.push(new am4charts.ValueAxis());  
    valueAxis1.title.text='No.of Users'
    let series1 = chart1.series.push(new am4charts.LineSeries());  
    series1.dataFields.valueY = "usage";  
    series1.dataFields.dateX = "month";  

    // Create second line chart (Mobile usage over months)  
    let chart2 = am4core.create("chartdiv2", am4charts.XYChart);  
    chart2.data = mobileData;  
    chart2.titles.create().text = "Location Wise Usage";
    let title2 = chart2.titles.create();
    title2.text = "Location Wise Usage";
    title2.fontSize = 17; // Adjust the font size as needed
    title2.fontWeight = "bold";
    chart2.width = am4core.percent(50);
    title2.paddingBottom=20
    let dateAxis2 = chart2.xAxes.push(new am4charts.DateAxis());  
    dateAxis2.dataFields.date = "month";  
    dateAxis2.title.text = "Months"; 
    
    let valueAxis2 = chart2.yAxes.push(new am4charts.ValueAxis());  
    valueAxis2.title.text='No.of Users';
    let series2 = chart2.series.push(new am4charts.LineSeries());  
    series2.dataFields.valueY = "usage";  
    series2.dataFields.dateX = "month";  
    chart1.logo.disabled = true;
    chart2.logo.disabled = true;
    this.chart1 = chart1;  
    this.chart2 = chart2;  
  });  













  let locationWiseData = [  
    { location: "APMEA", usage: 5000 },  
    { location: "Americas 1", usage: 3000 },  
    { location: "Americas 2", usage: 2000 },  
    { location: "Europe", usage: 4000 },  
  ];  
  

  // Create bar chart (Location-wise usage for one month)  
  let chart3 = am4core.create("chartdiv3", am4charts.XYChart);  
  chart3.data = locationWiseData;  
  // chart3.titles.create().text = "Location Wise Usage";
  let title2 = chart3.titles.create();
  title2.text = "Location Wise Usage";
  title2.fontSize = 17; // Adjust the font size as needed
  title2.fontWeight = "bold";
  let categoryAxis3 = chart3.xAxes.push(new am4charts.CategoryAxis());  
  categoryAxis3.dataFields.category = "location";  
  categoryAxis3.renderer.grid.template.location = 0;
  categoryAxis3.renderer.minGridDistance = 30;
  categoryAxis3.title.text = "Location"; 

  let valueAxis3 = chart3.yAxes.push(new am4charts.ValueAxis());  
  valueAxis3.title.text='No.of Users';

  let series3 = chart3.series.push(new am4charts.ColumnSeries());  
  series3.dataFields.valueY = "usage";  
  series3.dataFields.categoryX = "location";
  series3.columns.template.tooltipText = "{categoryX}: [bold]{valueY}[/]";
  series3.columns.template.fillOpacity = .8;
  series3.columns.template.strokeWidth = 2;

  chart3.logo.disabled = true;









}  




getLastThreeMonths(): string[] {
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const currentDate = new Date();
  const currentMonthIndex = currentDate.getMonth();
  
  const lastThreeMonths = [];
  for (let i = 2; i > 0; i--) {
      const monthIndex = (currentMonthIndex - i + 12) % 12;
      lastThreeMonths.push(months[monthIndex]);
  }
  
  return lastThreeMonths;
}


generateChartData() {
  const lastThreeMonths = this.getLastThreeMonths();

  const values = [
    // { gpt4: 23, gemini: 18, cohere: 15 },  // Sample values for the oldest month
    { gpt4: 26, cohere: 23, gemini: 18 },  // Sample values for the middle month
    { gpt4: 17, cohere: 13, gemini: 7 }   // Sample values for the current month
  ];


  return lastThreeMonths.map((month, index) => ({
        month: month,
        gpt4: values[index].gpt4,
        gemini: values[index].gemini,
        cohere: values[index].cohere
    }));
}


ngOnDestroy() {  
 
  this.zone.runOutsideAngular(() => {  
    if (this.chart1) {  
      this.chart1.dispose();  
    }  
    if (this.chart2) {  
      this.chart2.dispose();  
    }  
  });  
}  


}
