import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';
declare var bootstrap: any; // Declare bootstrap for TypeScript

@Component({
  selector: 'app-delete-user-data',
  templateUrl: './delete-user-data.component.html',
  styleUrls: ['./delete-user-data.component.css']
})
export class DeleteUserDataComponent implements OnInit {

  message: string = '';
  buttonContent: string = '';

  constructor(private conHistService: ConHistService, private router: Router) { }

  ngOnInit(): void {
    this.openModal();
  }

  openModal() {
    const myModal = new bootstrap.Modal(document.getElementById('deleteConfirmationModal'));
    myModal.show();
  }

  routeToNewConvs() {
    const myModal1 = bootstrap.Modal.getInstance(document.getElementById('cancelledModal'));
    myModal1.hide();
    this.router.navigate(['landing/new-conversation']);
  }

  onCancel() {
    this.message = 'Your data is not deleted. You can continue utilizing your previous conversations and documents. Continue for starting new conversation with E-GPT';
    this.buttonContent = 'Proceed';
    const myModal = bootstrap.Modal.getInstance(document.getElementById('deleteConfirmationModal'));
    myModal.hide();

    const myModal1 = new bootstrap.Modal(document.getElementById('cancelledModal'));
    myModal1.show();
  }

  onDelete() {
    this.conHistService.datapurge();
    this.message = "Your data has been successfully deleted.Continue for starting new conversation with E-GPT "
  this.buttonContent = 'Proceed';
  const myModal = bootstrap.Modal.getInstance(document.getElementById('deleteConfirmationModal'));
    myModal.hide();

    const myModal1 = new bootstrap.Modal(document.getElementById('cancelledModal'));
    myModal1.show();
    // Additional actions after deletion can be placed here
  }
}
