import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/services/admin/admin-service.service';

@Component({
  selector: 'app-llmfilters',
  templateUrl: './llmfilters.component.html',
  styleUrls: ['./llmfilters.component.css']
})
export class LLMFiltersComponent implements OnInit {
  hate!: number;
  sexual!: number ;
  selfHarm!: number ;
  violence!: number;
  updateMessage: string = '';
  showMessage: boolean = false;

  constructor(private adminServiceService: AdminServiceService) {
    console.log("Getting filters");
    
    this.adminServiceService.getFilters().subscribe(response => {
      console.log(response.hate);
      
      this.hate = response.hate/100;
      console.log(this.hate);
      
      this.sexual = response.sexual/100;
      this.selfHarm = response.self_harm/100;
      this.violence = response.violence/100;
    })
    
   }

  ngOnInit(): void {
    // this.hate = Number(localStorage.getItem('hate')) || 0.5;
    // this.sexual = Number(localStorage.getItem('sexual')) || 0.5;
    // this.selfHarm = Number(localStorage.getItem('selfHarm')) || 0.5;
    // this.violence = Number(localStorage.getItem('violence')) || 0.5;
  }

  updateValues(): void {
    try{
      this.adminServiceService.setFilters(this.hate,this.sexual,this.selfHarm, this.violence)

    }
    // localStorage.setItem('hate', this.hate.toString());
    // localStorage.setItem('sexual', this.sexual.toString());
    // localStorage.setItem('selfHarm', this.selfHarm.toString());
    // localStorage.setItem('violence', this.violence.toString());
    finally{
      this.updateMessage = 'Values have been updated!';
      this.showMessage = true;
      
      setTimeout(() => {
        this.showMessage = false;
      }, 3000); // Hide the message after 3 seconds
    
    }
    }

  getLabel(value: number): string {
    switch(value) {
      case 0: return 'Low';
      case 0.5: return 'Medium';
      case 1: return 'High';
      default: return '';
    }
  }
}
