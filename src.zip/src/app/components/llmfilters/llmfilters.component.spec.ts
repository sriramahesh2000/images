import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LLMFiltersComponent } from './llmfilters.component';

describe('LLMFiltersComponent', () => {
  let component: LLMFiltersComponent;
  let fixture: ComponentFixture<LLMFiltersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LLMFiltersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LLMFiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
