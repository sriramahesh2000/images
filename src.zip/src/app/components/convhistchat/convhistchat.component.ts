import { HttpClient } from '@angular/common/http';
import { Component, Input, SimpleChanges, ViewChild, ElementRef, AfterViewInit, HostListener, OnDestroy, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/services/admin/admin-service.service';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';
import { NewchartService, chartResponses } from 'src/app/services/newChart/newchart.service';

// interface UserProfile {
//   "@odata.context": string;
//   businessPhones: string[];
//   displayName: string;
//   givenName: string;
//   jobTitle: string | null;
//   id: string;
//   mail: string | null;
//   mobilePhone: string | null;
//   officeLocation: string | null;
//   preferredLanguage: string | null;
//   surname: string;
//   userPrincipalName: string;
// }

// @Component({
//   selector: 'app-convhistchat',
//   templateUrl: './convhistchat.component.html',
//   styleUrls: ['./convhistchat.component.css']
// })
// export class ConvhistchatComponent implements AfterViewInit, OnInit {
//   @ViewChild('chatContainer') chatContainer!: ElementRef;
//   @ViewChild('inputArea') inputArea!: ElementRef;
//   @Input() conversationId!: number;
//   enabledLLMs: any[] = [];
//   messages: chartResponses[] = [];
//   isLoading: boolean = false;
//   modelName: any = '';
//   showDropup: boolean = false;
//   firstModel: any;

//   constructor(private http: HttpClient, private newchartService: NewchartService, private conhistService: ConHistService, private adminServiceService: AdminServiceService) {
    
//     const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';
//     console.log("from constructor of new chart")
//     this.http.get(GRAPH_ENDPOINT)
//       .subscribe(profile => {
//         localStorage.setItem('profile', JSON.stringify(profile));
//         const upn = (profile as UserProfile).userPrincipalName;
//         console.log('Hola Mathabhi lululu : User Principal Name (UPN): ', upn);
//         localStorage.setItem('userProfileName', upn);
//       });

//     //  this.getEnabledLLM()
//   }

//   ngOnInit(): void {
//     this.getEnabledLLM();
//   }

//   ngOnChanges(changes: SimpleChanges): void {
//     if (changes['conversationId']) {
//       localStorage.setItem('currentConvId', this.conversationId.toString());
//       console.log('Selected conversation ID: from convhistchat', this.conversationId);

//       this.newchartService.getConvoFromId(this.conversationId).subscribe(
//         response => this.messages = response
//       );
//     }
//   }

//   ngAfterViewInit(): void {
//     this.scrollToBottom();
//   }

//   addMessage(message: string, sender: 'User' | 'bot' | 'Bot') {
//     setTimeout(() => this.scrollToBottom());

//     const convIdString = localStorage.getItem('conversationId');
//     const convId = convIdString ? parseInt(convIdString, 10) : 9999;
//     const newMessage: chartResponses = {
//       msg: message,
//       time: new Date().toLocaleTimeString(),
//       msg_type: sender,
//       id: 9999999,
//       feedback: '',
//       conv_id: convId,
//       response_from: 'User'
//     };
//     this.messages.push(newMessage);
//     setTimeout(() => this.scrollToBottom());
//   }

//   sendMessage() {
//     const message = this.inputArea.nativeElement.value.trim();
//     this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);

//     if (message !== '') {
//       this.addMessage(message, 'User');
//       this.inputArea.nativeElement.value = '';
//     }

//     this.isLoading = true; 

//     setTimeout(() => this.scrollToBottom());

//     this.newchartService.llmRes(message).subscribe(
//       response => {
//         console.log(response);
//         const newMessage: chartResponses = {
//           msg: response.msg,
//           time: response.time,
//           msg_type: response.msg_type,
//           id: response.id,
//           feedback: response.feedback,
//           conv_id: response.conv_id,
//           response_from: response.response_from
//         };
//         this.messages.push(newMessage);
//         this.isLoading = false; 
//         setTimeout(() => this.scrollToBottom());
//       },
//       error => {
//         this.isLoading = false; 
//         const newMessage: chartResponses = {
//           msg: "Oops, something went wrong",
//           time: new Date().toLocaleTimeString(),
//           msg_type: "assistant",
//           id: 999999,
//           feedback: 'neutral',
//           conv_id: 999999999,
//           response_from: "From frontend"
//         };
//         this.messages.push(newMessage);
//         setTimeout(() => this.scrollToBottom());
//       },
//       () => {
//         this.inputArea      .nativeElement.addEventListener('keypress', this.onKeyPress);
//       }
//     );

//     setTimeout(() => this.scrollToBottom());
//   }

//   modifyDay(dateTimeString: string) {
//     let date = new Date(dateTimeString);
//     let shortDate = date.toLocaleDateString();
//     let shortTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
//     return "Date Time: " + shortDate + " at " + shortTime;
//   }

//   onKeyPress(event: KeyboardEvent) {
//     const message = this.inputArea.nativeElement.value.trim();
//     var emptyOrNot = message.trim() == ''
//     if ((event.key === 'Enter' && this.isLoading) || (event.key === 'Enter' && emptyOrNot)) {
//       event.preventDefault();
//     } else if (event.key === 'Enter') {
//       this.sendMessage();
//     }
//   }

//   scrollToBottom() {
//     if (this.chatContainer && this.chatContainer.nativeElement) {
//       this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
//     }
//   }

//   likeMessage(event: MouseEvent,message: chartResponses) {
//     const icon = event.target as HTMLElement;
//     icon.classList.add('icon-clicked');
//     setTimeout(() => {
//       icon.classList.remove('icon-clicked');
//     }, 300);
//     if (message.feedback === 'liked') {
//       message.feedback = '';
//       this.conhistService.feedbckLikeDislike("neutral", message.id);
//     } else {
//       message.feedback = 'liked';
//       this.conhistService.feedbckLikeDislike("liked", message.id);
//     }
//   }

//   dislikeMessage(event: MouseEvent,message: chartResponses) {
//     const icon = event.target as HTMLElement;
//     icon.classList.add('icon-clicked');
//     setTimeout(() => {
//       icon.classList.remove('icon-clicked');
//     }, 300);
//     if (message.feedback === 'disliked') {
//       message.feedback = '';
//       this.conhistService.feedbckLikeDislike("neutral", message.id);
//     } else {
//       message.feedback = 'disliked';
//       this.conhistService.feedbckLikeDislike("disliked", message.id);
//     }
//   }

//   copyMessage(event: MouseEvent, message: chartResponses) {
//     const icon = event.target as HTMLElement;
//     icon.classList.add('icon-clicked');
//     setTimeout(() => {
//       icon.classList.remove('icon-clicked');
//     }, 300);
//     console.log(message.msg);
//     navigator.clipboard.writeText(message.msg);
//   }

//   disableSendButtonAndKeypress() {
//     const sendButton = document.querySelector('button');
//     if (sendButton) {
//       sendButton.setAttribute('disabled', 'true');
//     }
//     this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);
//   }

//   enableSendButtonAndKeypress() {
//     const sendButton = document.querySelector('button');
//     if (sendButton) {
//       sendButton.removeAttribute('disabled');
//     }
//     this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
//   }

//   getEnabledLLM() {
//     this.adminServiceService.getEnabledLLMS().subscribe(
//       response => {
//         this.enabledLLMs = response;  
//         this.firstModel = response[0].name;  
//         console.log("******** Enabled LLMs: ************** " + JSON.stringify(response) + response[0].name);  
//       },
//       error => console.log(error),
//       () => {
//         console.log("*********** First Model Name: ****** " + JSON.stringify(this.enabledLLMs[0]));
//         const modelId = this.enabledLLMs[0].id;
//         this.modelName = this.enabledLLMs[0].name;

//         const lsSelectedModel = localStorage.getItem('selectedModel');
//         console.log("Already Selected model: " + lsSelectedModel);

//         if (lsSelectedModel != null && lsSelectedModel !== '') {
//           this.modelName = lsSelectedModel;
//         } else {
//           this.modelName = this.enabledLLMs[0].name;
//         }
//       }
//     );  
//   }

//   toggleDropup() {
//     console.log("Toggling");
//     this.showDropup = !this.showDropup;
//   }

//   selectModel(event: any) {
//     const selectedEndpoint = event.target.value;
//     localStorage.setItem('selectedModel', selectedEndpoint);
//     this.modelName = selectedEndpoint;
//     console.log("Selected Model: " + this.modelName);
//   }

//   @HostListener('document:click', ['$event'])
//   onClick(event: MouseEvent) {
//     const target = event.target as HTMLElement;
//     if (!target.closest('.dropup')) {
//       this.showDropup = false;
//     }
//   }
// }





interface Message {
  content: string;
  timestamp: string;
  sender: 'User' | 'bot';
  UserReaction?: 'like' | 'dislike' | '';
}

@Component({
  selector: 'app-convhistchat',
  templateUrl: './convhistchat.component.html',
  styleUrls: ['./convhistchat.component.css']
})
export class ConvhistchatComponent implements AfterViewInit, OnDestroy, OnInit {
  @ViewChild('chatContainer') chatContainer!: ElementRef;
  @ViewChild('inputArea') inputArea!: ElementRef;
  @Input() conversationId!: number;
  enabledLLMs: any[] = [];
  messages: chartResponses[] = [];
  isLoading: boolean = false;
  modelName: any = "GPT-3.5";
  showDropup: boolean = false;

  constructor(private newchartService: NewchartService, private conhistService: ConHistService, private adminServiceService: AdminServiceService) {
    this.modelName = "GPT-3.5";
  }

  ngOnInit() {
    this.getEnabledLLM(); // Fetch the enabled LLMs
    this.modelName = localStorage.getItem('selectedModel'); // Retrieve the selected model from local storage
    this.modelName = "GPT-3.5";

    // Check if a model is already selected in localStorage
  }
  

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['conversationId']) {
      localStorage.setItem('currentConvId', this.conversationId.toString());
      console.log('Selected conversation ID: from convhistchat', this.conversationId);

      this.newchartService.getConvoFromId(this.conversationId).subscribe(
        response => this.messages = response
      );
    }
  }

  ngAfterViewInit() {
    this.scrollToBottom();
  }

  addMessage(message: string, sender: 'User' | 'bot' | 'Bot') {
    setTimeout(() => this.scrollToBottom());

    const convIdString = localStorage.getItem('conversationId');
    const convId = convIdString ? parseInt(convIdString, 10) : 9999;
    const newMessage: chartResponses = {
      msg: message,
      time: new Date().toLocaleTimeString(),
      msg_type: sender,
      id: 9999999,
      feedback: '',
      conv_id: convId,
      response_from: 'User'
    };
    this.messages.push(newMessage);
    setTimeout(() => this.scrollToBottom());
  }

  sendMessage() {
    const message = this.inputArea.nativeElement.value.trim();

    this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);

    if (message !== '') {
      this.addMessage(message, 'User');
      this.inputArea.nativeElement.value = '';
    }

    this.isLoading = true;
    setTimeout(() => this.scrollToBottom());

    this.newchartService.llmRes(message).subscribe(
      response => {
        console.log(response);
        const newMessage: chartResponses = {
          msg: response.msg,
          time: response.time,
          msg_type: response.msg_type,
          id: response.id,
          feedback: response.feedback,
          conv_id: response.conv_id,
          response_from: response.response_from
        };
        this.messages.push(newMessage);
        this.isLoading = false;
        setTimeout(() => this.scrollToBottom());
      },
      error => {
        this.isLoading = false;
        const newMessage: chartResponses = {
          msg: "Oops, something went wrong ",
          time: new Date().toLocaleTimeString(),
          msg_type: "assistant",
          id: 999999,
          feedback: 'neutral',
          conv_id: 999999999,
          response_from: "From Backend"
        };
        this.messages.push(newMessage);
        setTimeout(() => this.scrollToBottom());
      },
      () => {
        this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
      }
    );
    setTimeout(() => this.scrollToBottom());
  }

  modifyDay(dateTimeString: string) {
    let date = new Date(dateTimeString);
    let shortDate = date.toLocaleDateString();
    let shortTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return "Date Time: " + shortDate + " at " + shortTime;
  }

  onKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter' && this.isLoading) {
      event.preventDefault();
    } else if (event.key === 'Enter') {
      this.sendMessage();
    }
  }

  scrollToBottom() {
    if (this.chatContainer && this.chatContainer.nativeElement) {
      this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
    }
  }

  likeMessage(message: chartResponses) {
    if (message.feedback === 'liked') {
      message.feedback = '';
      this.conhistService.feedbckLikeDislike("neutral", message.id);
    } else {
      message.feedback = 'liked';
      this.conhistService.feedbckLikeDislike("liked", message.id);
    }
  }

  dislikeMessage(message: chartResponses) {
    if (message.feedback === 'disliked') {
      message.feedback = '';
      this.conhistService.feedbckLikeDislike("neutral", message.id);
    } else {
      message.feedback = 'disliked';
      this.conhistService.feedbckLikeDislike("disliked", message.id);
    }
  }

  copyMessage(event: MouseEvent, message: chartResponses) {
    const icon = event.target as HTMLElement;
    icon.classList.add('icon-clicked');
    setTimeout(() => {
      icon.classList.remove('icon-clicked');
    }, 300);
    console.log(message.msg);
    navigator.clipboard.writeText(message.msg);
  }

  disableSendButtonAndKeypress() {
    const sendButton = document.querySelector('button');
    if (sendButton) {
      sendButton.setAttribute('disabled', 'true');
    }
    this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);
  }

  enableSendButtonAndKeypress() {
    const sendButton = document.querySelector('button');
    if (sendButton) {
      sendButton.removeAttribute('disabled');
    }
    this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
  }

  getEnabledLLM() {
    this.adminServiceService.getEnabledLLMS().subscribe(response => {
      this.enabledLLMs = response;
      console.log("Enabled LLMs: " + response);
    });
  }

  ngOnDestroy() {
    // localStorage.removeItem('selectedModel')
  }

  toggleDropup() {
    console.log("Toggling");
    this.showDropup = !this.showDropup;
  }

  selectModel(event: any) {
    const selectedEndpoint = event.target.value;
    localStorage.setItem('selectedModel', selectedEndpoint);
    this.modelName = localStorage.getItem('selectedModel');
    localStorage.setItem('selectedModel', event.target.textContent.trim());

  }


  

  @HostListener('document:click', ['$event'])
  onClick(event: MouseEvent)
  {
    const target = event.target as HTMLElement;
    if (!target.closest('.dropup')) {
      this.showDropup = false;
    }
  }
//   splitMessage(message: string): {beforeCode: string, code: string, afterCode: string} {
//     const codeStartIndex = message.indexOf("```");
//     const codeEndIndex = message.lastIndexOf("```");

//     if (codeStartIndex !== -1 && codeEndIndex !== -1) {
//         const beforeCode = message.substring(0, codeStartIndex);
//         const code = message.substring(codeStartIndex + 3, codeEndIndex);
//         const afterCode = message.substring(codeEndIndex + 3);
//         return {beforeCode, code, afterCode};
//     }

//     return {beforeCode: message, code: "", afterCode: ""};
// }

splitMessage(message: string): Array<{ type: 'text' | 'code', content: string, language?: string }> {
  const segments: Array<{ type: 'text' | 'code', content: string, language?: string }> = [];
  const parts = message.split(/(```[\s\S]*?```)/); // Split message by code blocks

  parts.forEach(part => {
      if (part.startsWith('```') && part.endsWith('```')) {
          const codeContent = part.substring(3, part.length - 3).trim();
          const firstLineEndIndex = codeContent.indexOf('\n');
          let language = 'code';
          let content = codeContent;

          if (firstLineEndIndex !== -1) {
              const firstLine = codeContent.substring(0, firstLineEndIndex).trim();
              const remainingContent = codeContent.substring(firstLineEndIndex + 1).trim();

              if (firstLine.match(/^[a-zA-Z0-9]+$/)) {
                  language = firstLine;
                  content = remainingContent;
              }
          }

          segments.push({ type: 'code', content, language });
      } else {
          segments.push({ type: 'text', content: part.trim() });
      }
  });

  return segments;
}


}

