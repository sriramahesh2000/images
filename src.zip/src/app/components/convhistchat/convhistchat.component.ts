import { Component, Input, SimpleChanges, ViewChild, ElementRef, AfterViewInit, HostListener, OnDestroy, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/services/admin/admin-service.service';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';
import { NewchartService, chartResponses } from 'src/app/services/newChart/newchart.service';

interface Message {
  content: string;
  timestamp: string;
  sender: 'User' | 'bot';
  UserReaction?: 'like' | 'dislike' | '';
}

@Component({
  selector: 'app-convhistchat',
  templateUrl: './convhistchat.component.html',
  styleUrls: ['./convhistchat.component.css']
})
export class ConvhistchatComponent implements AfterViewInit, OnDestroy, OnInit {
  @ViewChild('chatContainer') chatContainer!: ElementRef;
  @ViewChild('inputArea') inputArea!: ElementRef;
  @Input() conversationId!: number;
  enabledLLMs: any[] = [];
  messages: chartResponses[] = [];
  isLoading: boolean = false;
  modelName: any = "GPT-3.5";
  showDropup: boolean = false;

  constructor(private newchartService: NewchartService, private conhistService: ConHistService, private adminServiceService: AdminServiceService) {
    this.modelName = "GPT-3.5";
  }

  ngOnInit() {
    this.getEnabledLLM(); // Fetch the enabled LLMs
    this.modelName = localStorage.getItem('selectedModel'); // Retrieve the selected model from local storage
    this.modelName = "GPT-3.5";

    // Check if a model is already selected in localStorage
  }
  

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['conversationId']) {
      localStorage.setItem('currentConvId', this.conversationId.toString());
      console.log('Selected conversation ID: from convhistchat', this.conversationId);

      this.newchartService.getConvoFromId(this.conversationId).subscribe(
        response => this.messages = response
      );
    }
  }

  ngAfterViewInit() {
    this.scrollToBottom();
  }

  addMessage(message: string, sender: 'User' | 'bot' | 'Bot') {
    setTimeout(() => this.scrollToBottom());

    const convIdString = localStorage.getItem('conversationId');
    const convId = convIdString ? parseInt(convIdString, 10) : 9999;
    const newMessage: chartResponses = {
      msg: message,
      time: new Date().toLocaleTimeString(),
      msg_type: sender,
      id: 9999999,
      feedback: '',
      conv_id: convId,
      response_from: 'User'
    };
    this.messages.push(newMessage);
    setTimeout(() => this.scrollToBottom());
  }

  sendMessage() {
    const message = this.inputArea.nativeElement.value.trim();

    this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);

    if (message !== '') {
      this.addMessage(message, 'User');
      this.inputArea.nativeElement.value = '';
    }

    this.isLoading = true;
    setTimeout(() => this.scrollToBottom());

    this.newchartService.llmRes(message).subscribe(
      response => {
        console.log(response);
        const newMessage: chartResponses = {
          msg: response.msg,
          time: response.time,
          msg_type: response.msg_type,
          id: response.id,
          feedback: response.feedback,
          conv_id: response.conv_id,
          response_from: response.response_from
        };
        this.messages.push(newMessage);
        this.isLoading = false;
        setTimeout(() => this.scrollToBottom());
      },
      error => {
        this.isLoading = false;
        const newMessage: chartResponses = {
          msg: "Oops, something went wrong \n ``` python code\n java code",
          time: new Date().toLocaleTimeString(),
          msg_type: "assistant",
          id: 999999,
          feedback: 'neutral',
          conv_id: 999999999,
          response_from: "From frontend"
        };
        this.messages.push(newMessage);
        setTimeout(() => this.scrollToBottom());
      },
      () => {
        this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
      }
    );
    setTimeout(() => this.scrollToBottom());
  }

  modifyDay(dateTimeString: string) {
    let date = new Date(dateTimeString);
    let shortDate = date.toLocaleDateString();
    let shortTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return "Date Time: " + shortDate + " at " + shortTime;
  }

  onKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter' && this.isLoading) {
      event.preventDefault();
    } else if (event.key === 'Enter') {
      this.sendMessage();
    }
  }

  scrollToBottom() {
    if (this.chatContainer && this.chatContainer.nativeElement) {
      this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
    }
  }

  likeMessage(message: chartResponses) {
    if (message.feedback === 'liked') {
      message.feedback = '';
      this.conhistService.feedbckLikeDislike("neutral", message.id);
    } else {
      message.feedback = 'liked';
      this.conhistService.feedbckLikeDislike("liked", message.id);
    }
  }

  dislikeMessage(message: chartResponses) {
    if (message.feedback === 'disliked') {
      message.feedback = '';
      this.conhistService.feedbckLikeDislike("neutral", message.id);
    } else {
      message.feedback = 'disliked';
      this.conhistService.feedbckLikeDislike("disliked", message.id);
    }
  }

  copyMessage(event: MouseEvent, message: chartResponses) {
    const icon = event.target as HTMLElement;
    icon.classList.add('icon-clicked');
    setTimeout(() => {
      icon.classList.remove('icon-clicked');
    }, 300);
    console.log(message.msg);
    navigator.clipboard.writeText(message.msg);
  }

  disableSendButtonAndKeypress() {
    const sendButton = document.querySelector('button');
    if (sendButton) {
      sendButton.setAttribute('disabled', 'true');
    }
    this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);
  }

  enableSendButtonAndKeypress() {
    const sendButton = document.querySelector('button');
    if (sendButton) {
      sendButton.removeAttribute('disabled');
    }
    this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
  }

  getEnabledLLM() {
    this.adminServiceService.getEnabledLLMS().subscribe(response => {
      this.enabledLLMs = response;
      console.log("Enabled LLMs: " + response);
    });
  }

  ngOnDestroy() {
    // localStorage.removeItem('selectedModel')
  }

  toggleDropup() {
    console.log("Toggling");
    this.showDropup = !this.showDropup;
  }

  selectModel(event: any) {
    const selectedEndpoint = event.target.value;
    localStorage.setItem('selectedModel', selectedEndpoint);
    this.modelName = localStorage.getItem('selectedModel');
    localStorage.setItem('selectedModel', event.target.textContent.trim());

  }


  

  @HostListener('document:click', ['$event'])
  onClick(event: MouseEvent)
  {
    const target = event.target as HTMLElement;
    if (!target.closest('.dropup')) {
      this.showDropup = false;
    }
  }
  splitMessage(message: string): {beforeCode: string, code: string, afterCode: string} {
    const codeStartIndex = message.indexOf("```");
    const codeEndIndex = message.lastIndexOf("```");

    if (codeStartIndex !== -1 && codeEndIndex !== -1) {
        const beforeCode = message.substring(0, codeStartIndex);
        const code = message.substring(codeStartIndex + 3, codeEndIndex);
        const afterCode = message.substring(codeEndIndex + 3);
        return {beforeCode, code, afterCode};
    }

    return {beforeCode: message, code: "", afterCode: ""};
}
}





  // import { Component, Input, SimpleChanges, ViewChild, ElementRef, AfterViewInit, HostListener, OnDestroy, OnInit } from '@angular/core';
// import { AdminServiceService } from 'src/app/services/admin/admin-service.service';
// import { ConHistService } from 'src/app/services/convHist/con-hist.service';
// import { NewchartService, chartResponses } from 'src/app/services/newChart/newchart.service';

// interface Message {
//   content: string;
//   timestamp: string;
//   sender: 'User' | 'bot';
//   UserReaction?: 'like' | 'dislike' | '';
// }

// @Component({
//   selector: 'app-convhistchat',
//   templateUrl: './convhistchat.component.html',
//   styleUrls: ['./convhistchat.component.css']
// })
// export class ConvhistchatComponent implements AfterViewInit, OnDestroy, OnInit {
//   @ViewChild('chatContainer') chatContainer!: ElementRef;
//   @ViewChild('inputArea') inputArea!: ElementRef;
//   @Input() conversationId!: number;
//   enabledLLMs: any[] = [];
//   messages: chartResponses[] = [];
//   isLoading: boolean = false;
//   modelName: any;
//   showDropup: boolean = false;


//   constructor(private newchartService: NewchartService, private conhistService: ConHistService, private adminServiceService: AdminServiceService) {
//     this.getEnabledLLM();
//     this.modelName = localStorage.getItem('selectedModel');
  
//     // Check if a model is already selected in localStorage
//     if (!this.modelName && this.enabledLLMs.length > 0) {
//       // If no model is selected and there are enabled LLMs available,
//       // set the first model as the default selected model
//       const defaultModelName = this.enabledLLMs[0].name;
//       localStorage.setItem('selectedModel', defaultModelName);
//       console.log("dfgdfgchvjbknlmjh "+defaultModelName);
//       this.modelName = defaultModelName;
//     }
//     // this.selectedModelName = localStorage.getItem('selectedModel'); 
//   }
//   ngOnInit() {
//     this.getEnabledLLM();
//     this.modelName = localStorage.getItem('selectedModel');
//     console.log("dfgdxgfchvjklh "+this.modelName);

//     // Check if a model is already selected in localStorage
//     if (!this.modelName && this.enabledLLMs.length > 0) {
//       // If no model is selected and there are enabled LLMs available,
//       // set the first model as the default selected model
//       const defaultModelName = this.enabledLLMs[0].name;
//       console.log("dfgdxgfchvjklh "+defaultModelName);
      
//       localStorage.setItem('selectedModel', defaultModelName);
//       this.modelName = defaultModelName;
//     }
//   }
  
//   ngOnChanges(changes: SimpleChanges): void {
//     if (changes['conversationId']) {
//       localStorage.setItem('currentConvId', this.conversationId.toString());
//       console.log('Selected conversation ID: from convhistchat', this.conversationId);

//       this.newchartService.getConvoFromId(this.conversationId).subscribe(
//         response => this.messages = response
//       );
//     }
//   }

//   ngAfterViewInit() {
//     this.scrollToBottom();
//   }

//   addMessage(message: string, sender: 'User' | 'bot' | 'Bot') {
//     setTimeout(() => this.scrollToBottom());

//     const convIdString = localStorage.getItem('conversationId');
//     const convId = convIdString ? parseInt(convIdString, 10) : 9999;
//     const newMessage: chartResponses = {
//       msg: message,
//       time: new Date().toLocaleTimeString(),
//       msg_type: sender,
//       id: 9999999,
//       feedback: '',
//       conv_id: convId,
//       response_from: 'User'
//     };
//     this.messages.push(newMessage);
//     setTimeout(() => this.scrollToBottom());
//   }

//   sendMessage() {
//     const message = this.inputArea.nativeElement.value.trim();

//     // Disable Enter key functionality
//     this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);

//     if (message !== '') {
//       this.addMessage(message, 'User');
//       this.inputArea.nativeElement.value = '';
//     }

//     this.isLoading = true;

//     setTimeout(() => this.scrollToBottom());

//     this.newchartService.llmRes(message).subscribe(
//       response => {
//         console.log(response);
//         const newMessage: chartResponses = {
//           msg: response.msg,
//           time: response.time,
//           msg_type: response.msg_type,
//           id: response.id,
//           feedback: response.feedback,
//           conv_id: response.conv_id,
//           response_from: response.response_from
//         };
//         this.messages.push(newMessage);
//         this.isLoading = false;
//         setTimeout(() => this.scrollToBottom());
//       },
//       error => {
//         this.isLoading = false;
//         const newMessage: chartResponses = {
//           msg: "Oops, something went wrong",
//           time: new Date().toLocaleTimeString(),
//           msg_type: "assistant",
//           id: 999999,
//           feedback: 'neutral',
//           conv_id: 999999999,
//           response_from: "From frontend"
//         };
//         this.messages.push(newMessage);
//         setTimeout(() => this.scrollToBottom());
//       },
//       () => {
//         // Enable Enter key functionality after response or error
//         this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
//       }
//     );

//     setTimeout(() => this.scrollToBottom());
//   }

//   modifyDay(dateTimeString: string) {
//     let date = new Date(dateTimeString);
//     let shortDate = date.toLocaleDateString();
//     let shortTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
//     return "Date Time: " + shortDate + " at " + shortTime;
//   }

//   onKeyPress(event: KeyboardEvent) {
//     if (event.key === 'Enter' && this.isLoading) {
//       event.preventDefault();
//     } else if (event.key === 'Enter') {
//       this.sendMessage();
//     }
//   }

//   scrollToBottom() {
//     if (this.chatContainer && this.chatContainer.nativeElement) {
//       this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
//     }
//   }

//   likeMessage(message: chartResponses) {
//     if (message.feedback === 'liked') {
//       message.feedback = '';
//       this.conhistService.feedbckLikeDislike("neutral", message.id);
//     } else {
//       message.feedback = 'liked';
//       this.conhistService.feedbckLikeDislike("liked", message.id);
//     }
//   }

//   dislikeMessage(message: chartResponses) {
//     if (message.feedback === 'disliked') {
//       message.feedback = '';
//       this.conhistService.feedbckLikeDislike("neutral", message.id);
//     } else {
//       message.feedback = 'disliked';
//       this.conhistService.feedbckLikeDislike("disliked", message.id);
//     }
//   }

//   copyMessage(event: MouseEvent, message: chartResponses) {
//     const icon = event.target as HTMLElement;
//     icon.classList.add('icon-clicked');
//     setTimeout(() => {
//       icon.classList.remove('icon-clicked');
//     }, 300);
//     console.log(message.msg);
//     navigator.clipboard.writeText(message.msg);
//   }

//   disableSendButtonAndKeypress() {
//     console.log('Disabling send button and keypress event');
//     const sendButton = document.querySelector('button');
//     if (sendButton) {
//       sendButton.setAttribute('disabled', 'true');
//     }
//     this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);
//   }

//   enableSendButtonAndKeypress() {
//     console.log('Enabling send button and keypress event');
//     const sendButton = document.querySelector('button');
//     if (sendButton) {
//       sendButton.removeAttribute('disabled');
//     }
//     this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
//   }

//   getEnabledLLM() {
//     this.adminServiceService.getEnabledLLMS().subscribe(response => {
//       this.enabledLLMs = response;
//       console.log("Enabled LLMs: " + response);
//     });
//   }
// ngOnDestroy(){
//   localStorage.removeItem('selectedModel')
// }
//   toggleDropup() {
//     console.log("Toggling");
//     this.showDropup = !this.showDropup;
//   }

//   selectModel(event: any) {
//     console.log("event");
    
//     const selectedEndpoint = event.target.value;
//     localStorage.setItem('selectedModel', selectedEndpoint);
//     this.modelName = localStorage.getItem('selectedModel');
//   }

//   @HostListener('document:click', ['$event'])
//   onClick(event: MouseEvent) {
//     const target = event.target as HTMLElement;
//     if (!target.closest('.dropup')) {
//       this.showDropup = false;
//     }
//   }
// }




// // import { Component, Input, SimpleChanges } from '@angular/core';
// // import { ViewChild, ElementRef, AfterViewInit } from '@angular/core'; 
// // import { AdminServiceService } from 'src/app/services/admin/admin-service.service';
// // import { ConHistService } from 'src/app/services/convHist/con-hist.service';
// // import { NewchartService, chartResponses } from 'src/app/services/newChart/newchart.service';

// // interface Message {    
// //   content: string;    
// //   timestamp: string;    
// //   sender: 'User' | 'bot';    
// //   UserReaction?: 'like' | 'dislike' | '';    
// // }    

// // @Component({
// //   selector: 'app-convhistchat',
// //   templateUrl: './convhistchat.component.html',
// //   styleUrls: ['./convhistchat.component.css']
// // })
// // export class ConvhistchatComponent implements AfterViewInit {    
// //   @ViewChild('chatContainer') chatContainer !: ElementRef;    
// //   @ViewChild('inputArea') inputArea !: ElementRef;    
// //   @Input()
// //   conversationId!: number;
// //   enabledLLMs:any[]=[]
// //   messages: chartResponses[] = [];   
// //   isLoading: boolean = false;
// // modelName: any;

// //   constructor(private newchartService: NewchartService, private conhistService: ConHistService, private adminServiceService: AdminServiceService) {
// //     this.getEnabledLLM();
// //     this.modelName = localStorage.getItem('selectedModel')
    
// //   }

// //   ngOnChanges(changes: SimpleChanges): void {
// //     if (changes['conversationId']) {
// //       localStorage.setItem('currentConvId', this.conversationId.toString());
// //       console.log('Selected conversation ID: from convhistchat', this.conversationId);

// //       this.newchartService.getConvoFromId(this.conversationId).subscribe(
// //         response => this.messages = response
// //       );
// //     }
// //   }

// //   ngAfterViewInit() {      
// //     this.scrollToBottom();      
// //   }      
  
// //   addMessage(message: string, sender: 'User' | 'bot' | 'Bot') {    
// //     setTimeout(() => this.scrollToBottom());    

// //     const convIdString = localStorage.getItem('conversationId');
// //     const convId = convIdString ? parseInt(convIdString, 10) : 9999;
// //     const newMessage: chartResponses = {
// //       msg: message,
// //       time: new Date().toLocaleTimeString(),
// //       msg_type: sender,
// //       id: 9999999,
// //       feedback:'',
// //       conv_id: convId,
// //       response_from:'User'
// //     };    
// //     this.messages.push(newMessage);    
// //     setTimeout(() => this.scrollToBottom());      
// //   }    
  


// //   sendMessage() {   
// //     const message = this.inputArea.nativeElement.value.trim();  

// //     // Disable Enter key functionality
// //     this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);  

// //     if (message !== '') {    
// //         this.addMessage(message, 'User');    
// //         this.inputArea.nativeElement.value = '';    
// //     }    

// //     this.isLoading = true;

// //     setTimeout(() => this.scrollToBottom()); 

// //     this.newchartService.llmRes(message).subscribe(
// //         response => {
// //             console.log(response);
// //             const newMessage: chartResponses = {
// //                 msg: response.msg,
// //                 time: response.time,
// //                 msg_type: response.msg_type,
// //                 id: response.id,
// //                 feedback: response.feedback,
// //                 conv_id: response.conv_id,
// //                 response_from: response.response_from
// //             };  
// //             this.messages.push(newMessage); 
// //             this.isLoading = false; 
// //             setTimeout(() => this.scrollToBottom()); 
// //         },
// //         error => {
// //             this.isLoading = false;    
// //             const newMessage: chartResponses = {
// //                 msg: "Oops, something went wrong",
// //                 time: new Date().toLocaleTimeString(),
// //                 msg_type: "assistant",
// //                 id: 999999,
// //                 feedback: 'neutral',
// //                 conv_id: 999999999,
// //                 response_from: "From frontend"
// //             };
// //             this.messages.push(newMessage); 
// //             setTimeout(() => this.scrollToBottom());
// //         },
// //         () => {
// //             // Enable Enter key functionality after response or error
// //             this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
// //         }
// //     );

// //     setTimeout(() => this.scrollToBottom());    
// // }

// // modifyDay(dateTimeString: string) {
// //   let date = new Date(dateTimeString);

// //   let shortDate = date.toLocaleDateString();
// //   let shortTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
// //   return "Date Time: "+shortDate+" at "+shortTime;
  
// // }
// // onKeyPress(event: KeyboardEvent) {    
// //   if (event.key === 'Enter' && this.isLoading) {    
// //       event.preventDefault();
// //   } else if (event.key === 'Enter') {
// //       this.sendMessage(); // Optionally, you can call sendMessage() here to send the message when Enter is pressed.
// //   }    
// // }

  
// //   scrollToBottom() {      
// //     if (this.chatContainer && this.chatContainer.nativeElement) {      
// //       this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;      
// //     }      
// //   }    
  
// //   likeMessage(message: chartResponses) {      
// //     if (message.feedback === 'liked') {      
// //       message.feedback = '';   
// //       this.conhistService.feedbckLikeDislike("neutral", message.id);   
// //     } else {      
// //       message.feedback = 'liked';  
// //       this.conhistService.feedbckLikeDislike("liked", message.id);    
// //     }      
// //   }    
  
// //   dislikeMessage(message: chartResponses) { 
// //     console.log('disliked');        
// //     if (message.feedback === 'disliked') {      
// //       message.feedback = ''; 
// //       this.conhistService.feedbckLikeDislike("neutral", message.id);  
// //     } else {      
// //       message.feedback = 'disliked';   
// //       this.conhistService.feedbckLikeDislike("disliked", message.id);     
// //     }   
// //   }   

// //   copyMessage(event: MouseEvent,message: chartResponses) {  
// //     const icon = event.target as HTMLElement;
// //     icon.classList.add('icon-clicked');
// //     setTimeout(() => {
// //       icon.classList.remove('icon-clicked');
// //     }, 300); 
// //     console.log(message.msg);   
// //     navigator.clipboard.writeText(message.msg);      
// //   }       





// //   disableSendButtonAndKeypress() {
// //     console.log('Disabling send button and keypress event');
// //     const sendButton = document.querySelector('button');
// //     if (sendButton) {
// //       sendButton.setAttribute('disabled', 'true');
// //     }
// //     this.inputArea.nativeElement.removeEventListener('keypress', this.onKeyPress);
// //   }
  
// //   enableSendButtonAndKeypress() {
// //     console.log('Enabling send button and keypress event');
// //     const sendButton = document.querySelector('button');
// //     if (sendButton) {
// //       sendButton.removeAttribute('disabled');
// //     }
// //     this.inputArea.nativeElement.addEventListener('keypress', this.onKeyPress);
// //   }

// // getEnabledLLM(){
// //   this.adminServiceService.getEnabledLLMS().subscribe(response => {
// //     this.enabledLLMs = response;
// //     console.log("Enabled LLMs: "+response);
    
// //   })
// // }



// // showDropup: boolean = false;

// // toggleDropup() {
// //   console.log("Toggling");
  
// //   this.showDropup = !this.showDropup;
// // }

// // selectModel(event: any) {
// //   const selectedEndpoint = event.target.value;
// //   localStorage.setItem('selectedModel', selectedEndpoint);
// //   this.modelName = localStorage.getItem('selectedModel')

// // }

// // }
