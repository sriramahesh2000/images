import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConvhistchatComponent } from './convhistchat.component';

describe('ConvhistchatComponent', () => {
  let component: ConvhistchatComponent;
  let fixture: ComponentFixture<ConvhistchatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConvhistchatComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConvhistchatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
