import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { AuthenticationResult, InteractionStatus, InteractionType, PopupRequest, RedirectRequest } from '@azure/msal-browser';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';  
import { HttpClient, HttpHeaders } from '@angular/common/http';

const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';

type ProfileType = {
  givenName?: string,
  surname?: string,
  userPrincipalName?: string,
  id?: string
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})




export class LoginComponent implements OnInit, OnDestroy {
agreeToTerms() {
  this.router.navigate(['/landing/new-conversation']);
}
  title = 'EnterpriseGPT';
  profile!: ProfileType;
  isIframe = false;
  loginDisplay = false;
  private readonly _destroying$ = new Subject<void>();

  constructor(
    @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private authService: MsalService,
    private msalBroadcastService: MsalBroadcastService,
    private router : Router,
    private http: HttpClient
  ) { }

  ngOnInit(): void {
    this.isIframe = window !== window.parent && !window.opener;

    this.msalBroadcastService.inProgress$
      .pipe(
        filter((status: InteractionStatus) => status === InteractionStatus.None),
        takeUntil(this._destroying$)
      )
      .subscribe(() => {
        this.setLoginDisplay();
      });
  }

  setLoginDisplay() {
    this.loginDisplay = this.authService.instance.getAllAccounts().length > 0;
  }

  login() {
    if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
      if (this.msalGuardConfig.authRequest) {
        // this.authService.loginPopup({ ...this.msalGuardConfig.authRequest, redirectUri: 'https://egpt-dwp.azurewebsites.net/' } as PopupRequest)
        this.authService.loginPopup({ ...this.msalGuardConfig.authRequest, redirectUri: 'http://localhost:4200' } as PopupRequest)
        .subscribe((response: AuthenticationResult) => {
            this.authService.instance.setActiveAccount(response.account);
            
          });
      } else {
        this.authService.loginPopup()
          .subscribe((response: AuthenticationResult) => {
            this.authService.instance.setActiveAccount(response.account);
            
          });
      }
    } else {
      if (this.msalGuardConfig.authRequest) {
        // this.authService.loginRedirect({ ...this.msalGuardConfig.authRequest,  redirectUri: 'https://egpt-dwp.azurewebsites.net/' } as RedirectRequest);
        this.authService.loginRedirect({ ...this.msalGuardConfig.authRequest,  redirectUri: 'http://localhost:4200' } as RedirectRequest);

      } else {
        this.authService.loginRedirect();
      }
    }
   
  }
  



  logout() {
    if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
      this.authService.logoutPopup({
        postLogoutRedirectUri: "/",
        mainWindowRedirectUri: "/"
      });
    } else {
      this.authService.logoutRedirect({
        postLogoutRedirectUri: "/",
      });
    }
    this.router.navigate(['/']);
  }

  ngOnDestroy(): void {
    this._destroying$.next(undefined);
    this._destroying$.complete();
  }
}
