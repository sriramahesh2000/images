import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PinConvComponent } from './pin-conv.component';

describe('PinConvComponent', () => {
  let component: PinConvComponent;
  let fixture: ComponentFixture<PinConvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PinConvComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PinConvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
