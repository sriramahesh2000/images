import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pin-conv',
  templateUrl: './pin-conv.component.html',
  styleUrls: ['./pin-conv.component.css']
})
export class PinConvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
