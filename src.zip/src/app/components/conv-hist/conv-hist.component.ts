import { Component, OnInit, OnDestroy, ElementRef, ChangeDetectorRef } from '@angular/core';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';

@Component({
  selector: 'app-conv-hist',
  templateUrl: './conv-hist.component.html',
  styleUrls: ['./conv-hist.component.css']
})
export class ConvHistComponent implements OnInit, OnDestroy {

  conversations: any[] = [];
  pinnedConversations: any[] = [];
  unpinnedConversations: any[] = [];
  editId: number | null = null;
  visibleDropdownId: number | null = null;
  selectedConversationId!: number;
  isLoading = false;
  
  constructor(
    private changeDetector: ChangeDetectorRef,
    private conHistService: ConHistService,
    private elementRef: ElementRef
  ) {
    document.addEventListener('click', (event) => {  
      const target = event.target as HTMLElement;  
      if (!target.closest('.conv-history')) {  
        this.visibleDropdownId = null;  
        this.changeDetector.detectChanges();  
      }  
    });
  }

  ngOnInit(): void {
    this.getHist();
  }

  ngOnDestroy(): void {
    document.removeEventListener('click', this.onDocumentClick.bind(this));
  }

  getHist(): void {
    this.isLoading = true;
    this.conHistService.getAllConvs().subscribe(data => {
      console.log("retrievd convos: "+ JSON.stringify(data));
      
      this.conversations = data;
      this.sortConversations(); 
      this.isLoading = false;
    });
   
    
  }

  selectConversation(id: number): void {
    localStorage.setItem('selectedConversationId', id.toString());
    this.selectedConversationId = id;
  }

  setEditId(id: number): void {
    this.editId = id;
  }

  rename(id: number): void {
    const convIndex = this.conversations.findIndex(conv => conv.id === id);
    if (convIndex !== -1) {
      this.conHistService.updateConvName(id, this.conversations[convIndex].conv_name);
        this.editId = null;  // Reset editId to hide the input field
        this.changeDetector.detectChanges();
      
    }
  }

  onInputBlur(id: number): void {
    this.rename(id);
  }

  toggleDropdown(id: number): void {
    this.visibleDropdownId = this.visibleDropdownId === id ? null : id;
  }

  isDropdownVisible(id: number): boolean {
    return this.visibleDropdownId === id;
  }

  delete(id: number): void {
    const index = this.conversations.findIndex(conv => conv.id === id);
    if (index !== -1) {
      this.conversations.splice(index, 1);
      this.conHistService.deleteConv(id).subscribe(() => this.sortConversations(),() => this.sortConversations(),() => this.sortConversations());
    }
  }

  pin(id: number, pinOrNot:any): void {
    const convIndex = this.conversations.findIndex(conv => conv.id === id);
    if (convIndex !== -1) {
      this.conversations[convIndex].pinned = !this.conversations[convIndex].pinned;
      this.conHistService.pinningConv(id,pinOrNot).subscribe(() => this.sortConversations());
    }
    // this.conHistService.pinningConv(id, pinOrNot);
  }

  sortConversations(): void {
    this.pinnedConversations = this.conversations.filter(conv => conv.pinned);
    this.unpinnedConversations = this.conversations.filter(conv => !conv.pinned).sort((a, b) => b.id - a.id);
    
    if (this.unpinnedConversations.length > 0) {
        this.selectedConversationId = this.unpinnedConversations[0].id;
    } 
    else{
      return;
    }
}


  onDocumentClick(event: MouseEvent): void {
    if (this.editId !== null) {
      const target = event.target as HTMLElement;
      const clickedInside = this.elementRef.nativeElement.contains(target);
      if (!clickedInside) {
        this.rename(this.editId);
      }
    }
  }
}
















// import { Component, OnInit, OnDestroy, ElementRef, ChangeDetectorRef } from '@angular/core';
// import { ConHistService } from 'src/app/services/convHist/con-hist.service';

// @Component({
//   selector: 'app-conv-hist',
//   templateUrl: './conv-hist.component.html',
//   styleUrls: ['./conv-hist.component.css']
// })
// export class ConvHistComponent implements OnInit, OnDestroy {

//   conversations: any[] = [];
//   pinnedConversations: any[] = [];
//   unpinnedConversations: any[] = [];
//   editId: number | null = null;
//   visibleDropdownId: number | null = null;
//   selectedConversationId = 1;
//   isLoading = false;
  
//   constructor(
//     private changeDetector: ChangeDetectorRef,
//     private conHistService: ConHistService,
//     private elementRef: ElementRef
//   ) {
//     document.addEventListener('click', (event) => {  
//       const target = event.target as HTMLElement;  
//       if (!target.closest('.conv-history')) {  
//         this.visibleDropdownId = null;  
//         this.changeDetector.detectChanges();  
//       }  
//     });
//   }

//   ngOnInit(): void {
//     this.getHist();
//   }

//   ngOnDestroy(): void {
//     document.removeEventListener('click', this.onDocumentClick.bind(this));
//   }

//   getHist(): void {
//     this.isLoading = true;
//     this.conHistService.getAllConvs().subscribe(data => {
//       this.conversations = data.filter((item: { id: number; }) => item.id==0);
//       this.sortConversations(); 
//       this.isLoading = false;
//     });
//     // console.log("After filter "+ JSON.stringify(this.conversations));
    
//   }

//   selectConversation(id: number): void {
//     localStorage.setItem('selectedConversationId', id.toString());
//     this.selectedConversationId = id;
//   }

//   setEditId(id: number): void {
//     this.editId = id;
//   }

//   rename(id: number): void {
//     const convIndex = this.conversations.findIndex(conv => conv.id === id);
//     if (convIndex !== -1) {
//       this.conHistService.updateConvName(id, this.conversations[convIndex].conv_name);
//         this.editId = null;  // Reset editId to hide the input field
//         this.changeDetector.detectChanges();
      
//     }
//   }

//   onInputBlur(id: number): void {
//     this.rename(id);
//   }

//   toggleDropdown(id: number): void {
//     this.visibleDropdownId = this.visibleDropdownId === id ? null : id;
//   }

//   isDropdownVisible(id: number): boolean {
//     return this.visibleDropdownId === id;
//   }

//   delete(id: number): void {
//     const index = this.conversations.findIndex(conv => conv.id === id);
//     if (index !== -1) {
//       this.conversations.splice(index, 1);
//       this.conHistService.deleteConv(id).subscribe(() => this.sortConversations());
//     }
//   }

//   pin(id: number): void {
//     const convIndex = this.conversations.findIndex(conv => conv.id === id);
//     if (convIndex !== -1) {
//       this.conversations[convIndex].pinned = !this.conversations[convIndex].pinned;
//       this.conHistService.pinningConv(id).subscribe(() => this.sortConversations());
//     }
//   }

//   sortConversations(): void {
//     this.pinnedConversations = this.conversations.filter(conv => conv.pinned);
//     this.unpinnedConversations = this.conversations.filter(conv => !conv.pinned).sort((a, b) => b.id - a.id);
//     this.selectedConversationId = this.unpinnedConversations[0].id;
//   }

//   onDocumentClick(event: MouseEvent): void {
//     if (this.editId !== null) {
//       const target = event.target as HTMLElement;
//       const clickedInside = this.elementRef.nativeElement.contains(target);
//       if (!clickedInside) {
//         this.rename(this.editId);
//       }
//     }
//   }
// }

















// // import { Component, OnInit, OnDestroy, ElementRef, ChangeDetectorRef } from '@angular/core';
// // import { ConHistService } from 'src/app/services/convHist/con-hist.service';

// // @Component({
// //   selector: 'app-conv-hist',
// //   templateUrl: './conv-hist.component.html',
// //   styleUrls: ['./conv-hist.component.css']
// // })
// // export class ConvHistComponent implements OnInit, OnDestroy {

// //   conversations: any[] = [];
// //   pinnedConversations: any[] = [];
// //   unpinnedConversations: any[] = [];
// //   editId: number | null = null;
// //   visibleDropdownId: number | null = null;
// //   selectedConversationId = 1;
// //   isLoading = false;
  
// //   constructor(
// //     private changeDetector: ChangeDetectorRef,
// //     private conHistService: ConHistService,
// //     private elementRef: ElementRef
// //   ) {
// //     document.addEventListener('click', (event) => {  
// //       const target = event.target as HTMLElement;  
// //       if (!target.closest('.conv-history')) {  
// //         this.visibleDropdownId = null;  
// //         this.changeDetector.detectChanges();  
// //       }  
// //     });
// //   }

// //   ngOnInit(): void {
// //     this.getHist();
// //   }

// //   ngOnDestroy(): void {
// //     document.removeEventListener('click', this.onDocumentClick.bind(this));
// //   }

// //   getHist(): void {
// //     this.isLoading = true;
// //     this.conHistService.getAllConvs().subscribe(data => {
// //       this.conversations = data.filter((item: { id: number; }) => item.id%2==0);
// //       this.sortConversations(); 
// //       this.isLoading = false;
// //     });
// //     // console.log("After filter "+ JSON.stringify(this.conversations));
    
// //   }

// //   selectConversation(id: number): void {
// //     localStorage.setItem('selectedConversationId', id.toString());
// //     this.selectedConversationId = id;
// //   }

// //   setEditId(id: number): void {
// //     this.editId = id;
// //   }

// //   rename(id: number): void {
// //     const convIndex = this.conversations.findIndex(conv => conv.id === id);
// //     if (convIndex !== -1) {
// //       this.conHistService.updateConvName(id, this.conversations[convIndex].conv_name);
// //         this.editId = null;  // Reset editId to hide the input field
// //         this.changeDetector.detectChanges();
      
// //     }
// //   }

// //   onInputBlur(id: number): void {
// //     this.rename(id);
// //   }

// //   toggleDropdown(id: number): void {
// //     this.visibleDropdownId = this.visibleDropdownId === id ? null : id;
// //   }

// //   isDropdownVisible(id: number): boolean {
// //     return this.visibleDropdownId === id;
// //   }

// //   delete(id: number): void {
// //     const index = this.conversations.findIndex(conv => conv.id === id);
// //     if (index !== -1) {
// //       this.conversations.splice(index, 1);
// //       this.conHistService.deleteConv(id).subscribe(() => this.sortConversations());
// //     }
// //   }

// //   pin(id: number): void {
// //     const convIndex = this.conversations.findIndex(conv => conv.id === id);
// //     if (convIndex !== -1) {
// //       this.conversations[convIndex].pinned = !this.conversations[convIndex].pinned;
// //       this.conHistService.pinningConv(id).subscribe(() => this.sortConversations());
// //     }
// //   }

// //   sortConversations(): void {
// //     this.pinnedConversations = this.conversations.filter(conv => conv.pinned);
// //     this.unpinnedConversations = this.conversations.filter(conv => !conv.pinned).sort((a, b) => b.id - a.id);
// //     this.selectedConversationId = this.unpinnedConversations[0].id;
// //   }

// //   onDocumentClick(event: MouseEvent): void {
// //     if (this.editId !== null) {
// //       const target = event.target as HTMLElement;
// //       const clickedInside = this.elementRef.nativeElement.contains(target);
// //       if (!clickedInside) {
// //         this.rename(this.editId);
// //       }
// //     }
// //   }
// // }



















// // // // import { Component, OnInit, OnDestroy, ElementRef, ChangeDetectorRef } from '@angular/core';
// // // // import { ConHistService, allConvRes } from 'src/app/services/convHist/con-hist.service';

// // // // @Component({
// // // //   selector: 'app-conv-hist',
// // // //   templateUrl: './conv-hist.component.html',
// // // //   styleUrls: ['./conv-hist.component.css']
// // // // })
// // // // export class ConvHistComponent implements OnInit, OnDestroy {

// // // //   conversations: any;
// // // //   editId: number | null = null;
// // // //   visibleDropdownId: number | null = null;
// // // //   dropdowns: any = {};
// // // // selectedConversationId!:number;
// // // // isLoading: boolean=false;

// // // //   constructor(
// // // //     private changeDetector: ChangeDetectorRef,
// // // //     private conHistService: ConHistService,
// // // //     private elementRef: ElementRef
// // // //   ) {
// // // //     document.addEventListener('click', this.onDocumentClick.bind(this));
// // // //   }

// // // //   ngOnInit(): void {
  
// // // //     this.getHist();
// // // //   }

// // // //   ngOnDestroy(): void {
// // // //     document.removeEventListener('click', this.onDocumentClick.bind(this));
// // // //   }

// // // //   getHist() {
// // // //     this.isLoading=true;
// // // //     this.conHistService.getAllConvs()
// // // //     .subscribe(data => {
// // // //       this.conversations = (data);
// // // //       this.selectedConversationId = this.conversations[0].id
// // // //       console.log("Selected Convo: "+this.selectConversation);
     
// // // //       this.sortConversations(); 
// // // //       this.selectConversation = this.conversations[0].id
// // // //       console.log("Selected Convo: "+this.selectConversation);
// // // //        localStorage.setItem('selectedConversationId',this.selectedConversationId.toString());
// // // //       console.log(JSON.stringify(data));
      
// // // //     });
// // // //     this.isLoading=false;
// // // //   }
// // // //   selectConversation(id: number): void {
// // // //     localStorage.setItem('selectedConversationId', id.toString());
// // // //     console.log(`Selected conversation ID ${id} stored in local storage`);
// // // //     this.selectedConversationId = +id;
// // // //   }

// // // //   setEditId(id: number): void {
// // // //     this.editId = id;
// // // //   }

// // // //   rename(id: number): void {
// // // //     const convIndex = this.conversations.findIndex((conv: { id: number; }) => conv.id === id);
// // // //     if (convIndex !== -1) {
// // // //       console.log(`Renamed conversation ID ${id} to ${this.conversations[convIndex].conv_name}`);
// // // //       this.editId = null;  // Reset editId to hide the input field
// // // //       this.conHistService.updateConvName(id,this.conversations[convIndex].conv_name)
// // // //       this.changeDetector.detectChanges();
// // // //     }
// // // //   }

// // // //   onInputBlur(id: number): void {
// // // //     this.rename(id);
// // // //   }

// // // //   toggleDropdown(id: number): void {
// // // //     if (this.visibleDropdownId === id) {
// // // //       this.visibleDropdownId = null;
// // // //     } else {
// // // //       this.visibleDropdownId = id;
// // // //     }
// // // //   }

// // // //   isDropdownVisible(id: number): boolean {
// // // //     return this.visibleDropdownId === id;
// // // //   }

// // // //   delete(id: number): void {
// // // //     const index = this.conversations.findIndex((conv: { id: number; }) => conv.id === id);
// // // //     if (index !== -1) {
// // // //       this.conversations.splice(index, 1);
// // // //     }
// // // //     this.conHistService.deleteConv(id);
// // // //   }

// // // //   pin(id: number): void {
// // // //     const convIndex = this.conversations.findIndex((conv: { id: number; }) => conv.id === id);
// // // //     if (convIndex !== -1) {
// // // //       this.conversations[convIndex].pinned = !this.conversations[convIndex].pinned;
// // // //       this.sortConversations();
// // // //       this.conversations = [...this.conversations]; // Create new array to trigger change detection
// // // //     }
// // // //     this.conHistService.pinningConv(id);
// // // //   }

// // // //   sortConversations(): void {
// // // //     this.conversations.sort((a: { pinned: any; id: number; }, b: { pinned: any; id: number; }) => {
// // // //       // First sort by the 'pinned' field
// // // //       if (a.pinned !== b.pinned) {
// // // //         return b.pinned ? 1 : -1;
// // // //       }
// // // //       // If 'pinned' is the same, then sort by the 'order' field
// // // //       return a.id - b.id;
// // // //     });
// // // //   }

// // // //   onDocumentClick(event: MouseEvent): void {
// // // //     if (this.editId !== null) {
// // // //       const target = event.target as HTMLElement;
// // // //       const clickedInside = this.elementRef.nativeElement.contains(target);
// // // //       if (!clickedInside) {
// // // //         this.rename(this.editId);
// // // //       }
// // // //     }
// // // //   }
// // // // }


// // // // import { Component, OnInit, OnDestroy, ElementRef, ChangeDetectorRef } from '@angular/core';
// // // // import { ConHistService, allConvRes } from 'src/app/services/convHist/con-hist.service';

// // // // @Component({
// // // //   selector: 'app-conv-hist',
// // // //   templateUrl: './conv-hist.component.html',
// // // //   styleUrls: ['./conv-hist.component.css']
// // // // })
// // // // export class ConvHistComponent implements OnInit, OnDestroy {

// // // //   conversations: any;
// // // //   editId: number | null = null;
// // // //   visibleDropdownId: number | null = null;
// // // //   dropdowns: any = {};
// // // // selectedConversationId=1;
// // // // isLoading: boolean=false;
// // // //   constructor(
// // // //     private changeDetector: ChangeDetectorRef,
// // // //     private conHistService: ConHistService,
// // // //     private elementRef: ElementRef
// // // //   ) {
// // // //     document.addEventListener('click', this.onDocumentClick.bind(this));
// // // //   }

// // // //   ngOnInit(): void {
// // // //     this.getHist();
// // // //   }

// // // //   ngOnDestroy(): void {
// // // //     document.removeEventListener('click', this.onDocumentClick.bind(this));
// // // //   }

// // // //   getHist() {
// // // //     this.isLoading=true;
// // // //     this.conHistService.getAllConvs()
// // // //     .subscribe(data => {
// // // //       this.conversations = (data);
// // // //       this.sortConversations(); 

// // // //       console.log(JSON.stringify(data));
      
// // // //     });
// // // //     this.isLoading=false;
// // // //   }
// // // //   selectConversation(id: number): void {
// // // //     localStorage.setItem('selectedConversationId', id.toString());
// // // //     console.log(`Selected conversation ID ${id} stored in local storage`);
// // // //     this.selectedConversationId = id;
// // // //   }

// // // //   setEditId(id: number): void {
// // // //     this.editId = id;
// // // //   }

// // // //   rename(id: number): void {
// // // //     const convIndex = this.conversations.findIndex((conv: { id: number; }) => conv.id === id);
// // // //     if (convIndex !== -1) {
// // // //       console.log(`Renamed conversation ID ${id} to ${this.conversations[convIndex].conv_name}`);
// // // //       this.editId = null;  // Reset editId to hide the input field
// // // //       this.conHistService.updateConvName(id,this.conversations[convIndex].conv_name)
// // // //       this.changeDetector.detectChanges();
// // // //     }
// // // //   }

// // // //   onInputBlur(id: number): void {
// // // //     this.rename(id);
// // // //   }

// // // //   toggleDropdown(id: number): void {
// // // //     if (this.visibleDropdownId === id) {
// // // //       this.visibleDropdownId = null;
// // // //     } else {
// // // //       this.visibleDropdownId = id;
// // // //     }
// // // //   }

// // // //   isDropdownVisible(id: number): boolean {
// // // //     return this.visibleDropdownId === id;
// // // //   }

// // // //   delete(id: number): void {
// // // //     const index = this.conversations.findIndex((conv: { id: number; }) => conv.id === id);
// // // //     if (index !== -1) {
// // // //       this.conversations.splice(index, 1);
// // // //     }
// // // //     this.conHistService.deleteConv(id);
// // // //   }

// // // //   pin(id: number): void {
// // // //     const convIndex = this.conversations.findIndex((conv: { id: number; }) => conv.id === id);
// // // //     if (convIndex !== -1) {
// // // //       this.conversations[convIndex].pinned = !this.conversations[convIndex].pinned;
// // // //       this.sortConversations();
// // // //       this.conversations = [...this.conversations]; // Create new array to trigger change detection
// // // //     }
// // // //     this.conHistService.pinningConv(id);
// // // //   }

// // // //   sortConversations(): void {
// // // //     this.conversations.sort((a: { pinned: any; id: number; }, b: { pinned: any; id: number; }) => {
// // // //       // First sort by the 'pinned' field
// // // //       if (a.pinned !== b.pinned) {
// // // //         return b.pinned ? 1 : -1;
// // // //       }
// // // //       // If 'pinned' is the same, then sort by the 'order' field
// // // //       return a.id - b.id;
// // // //     });
// // // //   }

// // // //   onDocumentClick(event: MouseEvent): void {
// // // //     if (this.editId !== null) {
// // // //       const target = event.target as HTMLElement;
// // // //       const clickedInside = this.elementRef.nativeElement.contains(target);
// // // //       if (!clickedInside) {
// // // //         this.rename(this.editId);
// // // //       }
// // // //     }
// // // //   }
// // // // }


// // // import { Component, OnInit, OnDestroy, ElementRef, ChangeDetectorRef } from '@angular/core';
// // // import { ConHistService } from 'src/app/services/convHist/con-hist.service';
 
// // // @Component({
// // //   selector: 'app-conv-hist',
// // //   templateUrl: './conv-hist.component.html',
// // //   styleUrls: ['./conv-hist.component.css']
// // // })
// // // export class ConvHistComponent implements OnInit, OnDestroy {
 
// // //   conversations: any[] = [];
// // //   pinnedConversations: any[] = [];
// // //   unpinnedConversations: any[] = [];
// // //   editId: number | null = null;
// // //   visibleDropdownId: number | null = null;
// // //   selectedConversationId = 1;
// // //   isLoading = false;
 
// // //   constructor(
// // //     private changeDetector: ChangeDetectorRef,
// // //     private conHistService: ConHistService,
// // //     private elementRef: ElementRef
// // //   ) {
// // //     document.addEventListener('click', (event) => {  
// // //       const target = event.target as HTMLElement;  
// // //       if (!target.closest('.conv-history')) {  
// // //         this.visibleDropdownId = null;  
// // //         this.changeDetector.detectChanges();  
// // //       }  
// // //     });
// // //   }
 
// // //   ngOnInit(): void {
// // //     this.getHist();
// // //   }
 
// // //   ngOnDestroy(): void {
// // //     document.removeEventListener('click', this.onDocumentClick.bind(this));
// // //   }
 
// // //   getHist(): void {
// // //     this.isLoading = true;
// // //     this.conHistService.getAllConvs().subscribe(data => {
// // //       this.conversations = (data) ;
// // //       this.sortConversations();
// // //       this.isLoading = false;
// // //     });
// // //   }
 
// // //   selectConversation(id: number): void {
// // //     localStorage.setItem('selectedConversationId', id.toString());
// // //     this.selectedConversationId = id;
// // //   }
 
// // //   setEditId(id: number): void {
// // //     this.editId = id;
// // //   }
 
// // //   rename(id: number): void {
// // //     const convIndex = this.conversations.findIndex(conv => conv.id === id);
// // //     if (convIndex !== -1) {
// // //       this.conHistService.updateConvName(id, this.conversations[convIndex].conv_name);
// // //         this.editId = null;  // Reset editId to hide the input field
// // //         this.changeDetector.detectChanges();
      
// // //     }
// // //   }
 
// // //   onInputBlur(id: number): void {
// // //     this.rename(id);
// // //   }
 
// // //   toggleDropdown(id: number): void {
// // //     this.visibleDropdownId = this.visibleDropdownId === id ? null : id;
// // //   }
 
// // //   isDropdownVisible(id: number): boolean {
// // //     return this.visibleDropdownId === id;
// // //   }
 
// // //   delete(id: number): void {
// // //     const index = this.conversations.findIndex(conv => conv.id === id);
// // //     if (index !== -1) {
// // //       this.conversations.splice(index, 1);
// // //       this.conHistService.deleteConv(id).subscribe(() => this.sortConversations());
// // //     }
// // //   }
 
// // //   pin(id: number): void {
// // //     const convIndex = this.conversations.findIndex(conv => conv.id === id);
// // //     if (convIndex !== -1) {
// // //       this.conversations[convIndex].pinned = !this.conversations[convIndex].pinned;
// // //       this.conHistService.pinningConv(id).subscribe(() => this.sortConversations());
// // //     }
// // //   }
 
// // //   sortConversations(): void {
// // //     this.pinnedConversations = this.conversations.filter(conv => conv.pinned);
// // //     this.unpinnedConversations = this.conversations.filter(conv => !conv.pinned).sort((a, b) => b.id - a.id);
// // //   }
 
// // //   onDocumentClick(event: MouseEvent): void {
// // //     if (this.editId !== null) {
// // //       const target = event.target as HTMLElement;
// // //       const clickedInside = this.elementRef.nativeElement.contains(target);
// // //       if (!clickedInside) {
// // //         this.rename(this.editId);
// // //       }
// // //     }
// // //   }
// // // }
 
 
 
 
 
 
 
 
 
 
 
 
 
 