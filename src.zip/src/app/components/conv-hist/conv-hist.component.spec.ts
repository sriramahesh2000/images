import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConvHistComponent } from './conv-hist.component';

describe('ConvHistComponent', () => {
  let component: ConvHistComponent;
  let fixture: ComponentFixture<ConvHistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConvHistComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConvHistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
