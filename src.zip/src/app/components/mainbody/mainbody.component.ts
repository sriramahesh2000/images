import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { MSAL_GUARD_CONFIG, MsalGuardConfiguration, MsalService, MsalBroadcastService } from '@azure/msal-angular';
import { InteractionType } from '@azure/msal-browser';
import { filter } from 'rxjs';
import { NewchartService } from 'src/app/services/newChart/newchart.service';
 
@Component({
  selector: 'app-mainbody',
  templateUrl: './mainbody.component.html',
  styleUrls: ['./mainbody.component.css']
})
export class MainbodyComponent implements OnInit {
  email: string = '';
  isExpanded = false;  
  currentRoute: string | undefined;
  isControlPanelActive: boolean = false;  // New property to track Control Panel click
  active!: boolean;
  classname: string = ' ';
 
  constructor(
    @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private authService: MsalService,
    private msalBroadcastService: MsalBroadcastService,
    private router: Router,
    private http: HttpClient,
    private newChatService: NewchartService
  ) {
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.currentRoute = event.url;
      this.updateActiveState();
    });
  }
 
  ngOnInit(): void {
    this.currentRoute = this.router.url;
    const emailId = localStorage.getItem('userProfileName') as string;
    const splits = emailId.split("@")[0].split(".");
    const firstName = splits[0].charAt(0).toUpperCase() + splits[0].slice(1);
    const lastName = splits[1].charAt(0).toUpperCase() + splits[1].slice(1);
    const fullName = `${firstName} ${lastName}`;
    this.email = fullName;
    console.log("Name: "+ this.email);
    
  }
 
  logout() {
    if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
      this.authService.logoutPopup({
        postLogoutRedirectUri: "/",
        mainWindowRedirectUri: "/"
      });
    } else {
      this.authService.logoutRedirect({
        postLogoutRedirectUri: "/",
      });
    }
    this.router.navigate(['/']);
  }
 
  onNavItemClicked(itemName: string) {
    if (itemName === '/landing/controls') {
      this.active = true;
      this.classname = 'imgs';
    } else {
      this.active = false;
    }
    this.router.navigate([itemName]); // Navigate to the clicked item
  }
 
  updateActiveState() {
    if (this.currentRoute?.includes('/landing/controls')) {
      this.active = true;
      this.classname = 'imgs';
    } else {
      this.active = false;
    }
    this.isControlPanelActive = this.active;
  }
 
  isActive(path: string): boolean {
    return this.currentRoute === path;
  }
 
  navItems = [    
    {icon: 'comments', text: 'New Conversation', path: '/landing/new-conversation',type:'regular', id:'id1'},    
    {icon: 'clock', text: 'Conversation History', path: '/landing/conversation-history',type:'regular',id:'id2'},
    {icon:'file', text:'Docs',path:'/landing/documentAI',type:'regular',id:'id3'},   
    {icon: 'chart-bar', text: 'Dashboard', path: '/landing/dashboard',type:'regular',id:'id4'},  
    {icon:'sliders', text:'Control Panel', path:'/landing/controls',type:'solid',id:'id5'},
  ];  
}


// import { HttpClient } from '@angular/common/http';
// import { Component, Inject, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { MSAL_GUARD_CONFIG, MsalGuardConfiguration, MsalService, MsalBroadcastService } from '@azure/msal-angular';
// import { InteractionType } from '@azure/msal-browser';
// import { NewchartService } from 'src/app/services/newChart/newchart.service';


// declare var bootstrap: any; 
// @Component({
//   selector: 'app-mainbody',
//   templateUrl: './mainbody.component.html',
//   styleUrls: ['./mainbody.component.css']
// })
// export class MainbodyComponent implements OnInit {
//   logout() {
//     if (this.msalGuardConfig.interactionType === InteractionType.Popup) {
//       this.authService.logoutPopup({
//         postLogoutRedirectUri: "/",
//         mainWindowRedirectUri: "/"
//       });
//     } else {
//       this.authService.logoutRedirect({
//         postLogoutRedirectUri: "/",
//       });
//     }
//     this.router.navigate(['/']);
//   }

  

// onNavItemClicked(itemName: string) {
//   if (itemName == 'New Conversation') {
//     this.newChatService.getNewChartId();
//   }
// }
// email:string=''

//   constructor(
//     @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
//     private authService: MsalService,
//     private msalBroadcastService: MsalBroadcastService,
//     private router : Router,
//     private http: HttpClient,
//     private newChatService : NewchartService
//   ) { }

//   ngOnInit(): void {
//     this.currentRoute = this.router.url;
//     const emailId = localStorage.getItem('userProfileName') as string;
//     const splits = emailId.split("@")[0].split(".");
//     const firstName = splits[0].charAt(0).toUpperCase() + splits[0].slice(1);
//     const lastName = splits[1].charAt(0).toUpperCase() + splits[1].slice(1);
//     const fullName = `${firstName} ${lastName}`;
//     this.email = fullName;

//   }
//   isExpanded = false;  
//   currentRoute: string | undefined;
//   isActive(path: string): boolean {
//     return this.currentRoute === path;
//   }
  
//   navItems = [    
//     {icon: 'comments', text: 'New Conversation', path: '/landing/new-conversation',type:'regular'},    
//     {icon: 'clock', text: 'Conversation History', path: '/landing/conversation-history',type:'regular'}, 
//     {icon:'file', text:'Docs',path:'/landing/documentAI',type:'regular'},   
//     // {icon: 'star', text: 'Important Conversation', path: '/landing/important-conversation'},  
//     {icon: 'chart-bar', text: 'Dashboard', path: '/landing/dashboard',type:'regular'},  
//     // {icon: 'public', text: 'Worldview', path: '/landing/worldview'}, 
//     {icon:'sliders', text:'Control Panel', path:'/landing/controls',type:'solid'},
//     // {icon: 'toolbox', text: 'GenAI Control', path: '/landing/genaiControl',type:'solid'},
//     // {icon: 'filter_alt', text: 'Content Filters', path: '/landing/contentFilters',type:'regular'},
//     // {icon: 'library_books', text: 'Enterprise Dictionary', path: '/landing/enterpriseDictionary',type:'regular'},
//     // {icon: 'settings_remote', text: 'System Prompt', path: '/landing/systemPrompt',type:'regular'},
   
//   ];  
  
// }
