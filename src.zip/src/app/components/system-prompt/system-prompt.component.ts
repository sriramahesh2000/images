import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/services/admin/admin-service.service';

@Component({
  selector: 'app-system-prompt',
  templateUrl: './system-prompt.component.html',
  styleUrls: ['./system-prompt.component.css']
})
export class SystemPromptComponent implements OnInit {

  constructor(private adminService : AdminServiceService) { }

  ngOnInit(): void {
    this.adminService.retrieveSysPrompt().subscribe(
      response =>{
        console.log("Retrieved System prompt: "+ JSON.stringify(response));
        this.editableContent = response.prompt;
      }
    )
  }
  editing = false;  
  editableContent = ""
  // editableContent = "Act as a corporate assistant for employees, your primary goal is to provide exceptional support by thoroughly understanding prompts and offering highly helpful responses. Maintain a professional, formal, and polite tone throughout our interactions. If any questions require clarification, request further information to ensure accurate assistance. If necessary, utilize internet resources, search the enterprise dictionary or library, and refer to companies policies to provide accurate information. In cases where uncertainty arises, direct users to relevant resources or human representatives. Prioritize cultural sensitivity, maintain consistency, and always uphold a polite demeanor"
 
  
  saveContent() {  
    this.editing = false;  
    this.adminService.updateSysPrompt(this.editableContent)
  }  

}
