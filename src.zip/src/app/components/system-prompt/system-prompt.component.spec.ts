import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemPromptComponent } from './system-prompt.component';

describe('SystemPromptComponent', () => {
  let component: SystemPromptComponent;
  let fixture: ComponentFixture<SystemPromptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SystemPromptComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SystemPromptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
