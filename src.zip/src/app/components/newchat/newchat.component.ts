  
import { HttpClient } from '@angular/common/http';
import { Component, ViewChild, ElementRef, AfterViewInit, OnInit } from '@angular/core';    
import { NewchartService, Message } from 'src/app/services/newChart/newchart.service';

// const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';
interface UserProfile {
    "@odata.context": string;
    businessPhones: string[];
    displayName: string;
    givenName: string;
    jobTitle: string | null;
    id: string;
    mail: string | null;
    mobilePhone: string | null;
    officeLocation: string | null;
    preferredLanguage: string | null;
    surname: string;
    userPrincipalName: string;
   }

@Component({    
  selector: 'app-newchat',    
  templateUrl: './newchat.component.html',    
  styleUrls: ['./newchat.component.css']    
})    
export class NewchatComponent implements AfterViewInit, OnInit {


  messages: Message[] =[]
  // [
  //   {
  //     content: "Hello! Good day. How can I help you?", timestamp: "10:00 AM", sender: 'bot', userReaction: '',
  //     id: ''
  //   },
  //   {
  //     content: "I need some information regarding various Gen AI models available", timestamp: "10:01 AM", sender: 'user', userReaction: '',
  //     id: ''
  //   }
  // ];
  
  constructor(private http: HttpClient, private newChatService: NewchartService) {
    const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';
    console.log("from constructor of new chart")
    this.http.get(GRAPH_ENDPOINT)
      .subscribe(profile => {
        localStorage.setItem('profile', JSON.stringify(profile));
        const upn = (profile as UserProfile).userPrincipalName;
        console.log('Hola Mathabhi lululu : User Principal Name (UPN): ', upn);
        localStorage.setItem('userProfileName', upn);
      });
  }

  ngOnInit(): void {
    

    this.newChatService.getNewChartId();
  }    

  @ViewChild('chatContainer') chatContainer!: ElementRef;    
  @ViewChild('inputArea') inputArea!: ElementRef;    
  


  ngAfterViewInit() {      
    this.scrollToBottom();      
  }      
  
  addMessage(message: Message) {    
    this.messages.push(message);    
    setTimeout(() => this.scrollToBottom());      
  }    
  
  sendMessage() {    
    const messageText = this.inputArea.nativeElement.value.trim();    
    if (messageText !== '') {    
      const userMessage: Message = {
        content: messageText,
        timestamp: new Date().toLocaleTimeString(),
        sender: 'user',
        userReaction: '',
        id: ''
      };    
      this.addMessage(userMessage); // Add user message to messages array    
      this.newChatService.updateMessages(
        localStorage.getItem('userProfileName') || '', // Retrieve username from localStorage
        localStorage.getItem('newChartId')||'', // Retrieve chartId from localStorage
        messageText
      ).subscribe(response => {
        this.addMessage(response); // Add the response to messages array
      });
      this.inputArea.nativeElement.value = '';    
    }    
    this.scrollToBottom();    
  }    
  
  onKeyPress(event: KeyboardEvent) {    
    if (event.key === 'Enter') {    
      this.sendMessage();    
    }    
  }    
  
  scrollToBottom() {      
    if (this.chatContainer && this.chatContainer.nativeElement) {      
      this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;      
    }      
  }    
  
  likeMessage(message: Message) {      
    if (message.userReaction === 'like') {      
      message.userReaction = '';      
    } else {      
      message.userReaction = 'like';      
    }      
  }      
  
  dislikeMessage(message: Message) { 
    console.log('disliked')        
    if (message.userReaction === 'dislike') {      
      message.userReaction = '';      
    } else {      
      message.userReaction = 'dislike';      
    }      
  }      
  
  copyMessage(message: Message) {   
    console.log(message.content)   
    navigator.clipboard.writeText(message.content);      
  }    
  
  



  // likeMessage(message: Message) {      
  //   if (message.userReaction === 'like') {      
  //     message.userReaction = '';      
  //   } else {      
  //     message.userReaction = 'like';      
  //     this.newChatService.updateReactions(
  //       localStorage.getItem('userProfileName') || '', // Retrieve username from localStorage
  //       message.id, // Assuming each message has a unique ID
  //       'like'
  //     ).subscribe(response => {
  //       // Handle response if necessary
  //     });
  //   }      
  // }      
  
  // dislikeMessage(message: Message) { 
  //   if (message.userReaction === 'dislike') {      
  //     message.userReaction = '';      
  //   } else {      
  //     message.userReaction = 'dislike';      
  //     this.newChatService.updateReactions(
  //       localStorage.getItem('userProfileName') || '', // Retrieve username from localStorage
  //       message.id, // Assuming each message has a unique ID
  //       'dislike'
  //     ).subscribe(response => {
  //       // Handle response if necessary
  //     });
  //   }      
  // }
  
}   
