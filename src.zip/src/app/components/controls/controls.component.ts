import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-controls',
  templateUrl: './controls.component.html',
  styleUrls: ['./controls.component.css']
})
export class ControlsComponent implements OnInit {


  constructor() { }
  editing = false;  
  editableContent = "Act as a corporate assistant for employees, your primary goal is to provide exceptional support by thoroughly understanding prompts and offering highly helpful responses. Maintain a professional, formal, and polite tone throughout our interactions. If any questions require clarification, request further information to ensure accurate assistance. If necessary, utilize internet resources, search the enterprise dictionary or library, and refer to companies policies to provide accurate information. In cases where uncertainty arises, direct users to relevant resources or human representatives. Prioritize cultural sensitivity, maintain consistency, and always uphold a polite demeanor"
 
  
  saveContent() {  
    this.editing = false;  
  }  
  
  ngOnInit(): void {
  }

  selectedFile: File|null = null;  
  
    onFileSelected(event: Event) {  
      const target = event.target as HTMLInputElement;  
      this.selectedFile = target.files ? target.files[0] : null;  
      this.onUpload();    
    }  
  
    onUpload() {  
      if (this.selectedFile) {  
        const fd = new FormData();  
        fd.append('file', this.selectedFile, this.selectedFile.name);  
        // Here you can call your service to send the file to your server  
       
    }  
    }

}
