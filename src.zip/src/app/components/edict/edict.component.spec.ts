import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EDictComponent } from './edict.component';

describe('EDictComponent', () => {
  let component: EDictComponent;
  let fixture: ComponentFixture<EDictComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EDictComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EDictComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
