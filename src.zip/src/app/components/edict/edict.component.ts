import { ChangeDetectorRef, Component, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminServiceService } from 'src/app/services/admin/admin-service.service';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';

@Component({
  selector: 'app-edict',
  templateUrl: './edict.component.html',
  styleUrls: ['./edict.component.css']
})
export class EDictComponent implements OnInit {

  edictsWords: any = [];
  isLoading!: boolean;
  wordForm: FormGroup;
  wordAdded: boolean = false;
  visibleDropdownId: number | null = null;
  editId: number | null = null;

  constructor(
    private formBuilder: FormBuilder, 
    private adminServiceService: AdminServiceService,     
    private changeDetector: ChangeDetectorRef,    
    private elementRef: ElementRef
  ) {
    this.wordForm = this.formBuilder.group({
      // word: ['', [Validators.required, Validators.minLength(5)]],
      // meaning: ['', [Validators.required, Validators.minLength(5)]]
    });

    document.addEventListener('click', (event) => {  
      const target = event.target as HTMLElement;  
      if (!target.closest('.conv-history')) {  
        this.visibleDropdownId = null;  
        this.changeDetector.detectChanges();  
      }  
    });
  }

  ngOnInit(): void {
    this.getAllWords();
  }

  getAllWords() {
    this.isLoading = true;
    this.adminServiceService.getAllWords().subscribe(response => {
      console.log("Edict words: " + JSON.stringify(response));
      this.edictsWords = response;
      this.isLoading = false;
    });
  }

  toggleDropdown(id: number): void {
    this.visibleDropdownId = this.visibleDropdownId === id ? null : id;
  }

  isDropdownVisible(id: number): boolean {
    return this.visibleDropdownId === id;
  }

  setEditId(id: number): void {
    this.editId = id;
  }

  onSubmit() {
    if (this.wordForm.valid) {
      const wordValue = this.wordForm.value.word;
      const meaningValue = this.wordForm.value.meaning;
      // Handle form submission logic
      console.log('Word:', wordValue);
      console.log('Meaning:', meaningValue);
      this.adminServiceService.addEdictword(wordValue, meaningValue).subscribe(() => {
        this.getAllWords();
      });
      this.wordForm.reset();
      this.wordAdded = true;
      setTimeout(() => {
        this.wordAdded = false;
      }, 1000);
      this.getAllWords()
    }
  }

  deleteWord(id: number) {
    console.log("Deleting Id: "+ id);
    
    this.adminServiceService.removeDictWord(id).subscribe(
      response => this.getAllWords(),
      err => this.getAllWords()
     
    );
  }
  
}
