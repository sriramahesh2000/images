

import { Component, OnInit } from '@angular/core';
import { error } from 'jquery';
import { AdminServiceService, allLLMS } from 'src/app/services/admin/admin-service.service';
declare var bootstrap: any;

interface Model {
  name: string;
  endpoint: string;
  key: string;
  enabled: boolean; 
}

@Component({
  selector: 'app-llmcontrols',
  templateUrl: './llmcontrols.component.html',
  styleUrls: ['./llmcontrols.component.css']
})
export class LLMControlsComponent implements OnInit {

  isLoading:boolean = true
  modalTitle: string = '';
  llmModels: allLLMS[] = [];
  editModel: allLLMS = {
    id: 0,
    name: '',
    endpoint: '',
    key: '',
    enabled: false
  };
  editModelIndex!: number | null;
  private editModal: any;
displayStatus: string='';

  constructor(private adminServiceService: AdminServiceService) {
   
    this.getAllLLMS();
    
  }

  ngOnInit(): void {}

  addNewLLM() {
    this.editModel = { id: 0, name: '', endpoint: '', key: '', enabled: false };
    this.modalTitle = 'Add New LLM';
    this.editModelIndex = null;
    this.editModal = new bootstrap.Modal(document.getElementById('editModelModal'));
    this.editModal.show();
  }
  
  closeModal() {
    const myModal = bootstrap.Modal.getInstance(document.getElementById('editModelModal'));
    myModal.hide();
  }

  deleteModel(id: number, name:string) {
    const localStoragename = localStorage.getItem('selectedModel')
    if(localStoragename == name){
      localStorage.setItem('selectedModel','')
    }
    console.log(`Delete method called for model id: ${id}`);
    this.adminServiceService.removeLLM(id).subscribe(() => {
      this.setDisplayStatus("Successfully deleted the Gen AI configuration");
      this.getAllLLMS();
    } ,
  error =>{
    this.getAllLLMS()
    console.log("Error: "+ JSON.stringify(error));
    if(error.error.error == 'At least one record must be kept.') this.setDisplayStatus("At least one Gen AI should be present.");


    
  } );
  }

  toggleEnableDisable(id: number): void {
    console.log("Toggle log");
    
    const model = this.llmModels.find(m => m.id === id);
    if (model) {
      this.adminServiceService.enableDisableLLM(id, !model.enabled).subscribe(() => 
        {
      this.getAllLLMS();
      console.log("toggle: +"+ !model.enabled );
      if(model.enabled)
      this.displayStatus = "Disabled the selected LLM";
    else  this.displayStatus = "Enabled the selected LLM";
    }
      ,
    error => {
      console.log("Toggle Error: "+ JSON.stringify(error));
      console.log("Error is: "+ error.error.error);
      if(error.error.error == 'At least one instance should be enabled') this.setDisplayStatus("At least one Gen AI model should be enabled.");
      
    });
    }
    this.getAllLLMS();
  }

  editModelDetails(index: number): void {
    this.editModelIndex = index;
    this.editModel = { ...this.llmModels[index] };
    this.modalTitle = "Modify LLM Config";
    this.editModal = new bootstrap.Modal(document.getElementById('editModelModal'));
    this.editModal.show();
  }

  formatKey(key: string): string {
    const visiblePart = key.substring(0, 4);
    const maskedPart = '*'.repeat(key.length - 4);
    return visiblePart + maskedPart;
  }

  saveChanges(): void {    
  
  
    if (this.editModelIndex !== undefined && this.editModelIndex !== null) {  
      console.log("Updating LLM");
        
      this.adminServiceService.updateLLM(this.editModel.id, this.editModel.name, this.editModel.endpoint, this.editModel.key).subscribe(() => {
        this.getAllLLMS();
        this.setDisplayStatus("Model updated successfully.");
        
      });
    } else {    
      console.log("adding llm");
      this.adminServiceService.addLLM(this.editModel.name, this.editModel.endpoint, this.editModel.key).subscribe(() =>{
        this.getAllLLMS();
        this.setDisplayStatus("Model added successfully.");
      } );
    }    
    this.editModal.hide();    
  } 


  getAllLLMS() {
    this.isLoading = true;
    this.adminServiceService.getLLMList().subscribe(response => {
      this.llmModels = response;
    }, error => {
      console.error("Error occurred while fetching LLMs:", error);
    }, () => {
      this.isLoading = false;
    });
  }

  setDisplayStatus(message: string): void {
    this.displayStatus = message;
    setTimeout(() => {
      this.displayStatus = '';
    }, 11000);
  }
  

}
