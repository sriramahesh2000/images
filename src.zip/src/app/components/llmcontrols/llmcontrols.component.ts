

import { Component, OnInit } from '@angular/core';
import { AdminServiceService, allLLMS } from 'src/app/services/admin/admin-service.service';
declare var bootstrap: any;

interface Model {
  name: string;
  endpoint: string;
  key: string;
  enabled: boolean; 
}

@Component({
  selector: 'app-llmcontrols',
  templateUrl: './llmcontrols.component.html',
  styleUrls: ['./llmcontrols.component.css']
})
export class LLMControlsComponent implements OnInit {

  isLoading:boolean = true
  modalTitle: string = '';
  llmModels: allLLMS[] = [];
  editModel: allLLMS = {
    id: 0,
    name: '',
    endpoint: '',
    key: '',
    enabled: false
  };
  editModelIndex!: number;
  private editModal: any;

  constructor(private adminServiceService: AdminServiceService) {
   
    this.getAllLLMS();
    
  }

  ngOnInit(): void {}

  addNewLLM() {
    this.editModel = { id: 0, name: '', endpoint: '', key: '', enabled: false };
    this.modalTitle = 'Add New LLM';
    this.editModal = new bootstrap.Modal(document.getElementById('editModelModal'));
    this.editModal.show();
  }
  
  closeModal() {
    const myModal = bootstrap.Modal.getInstance(document.getElementById('editModelModal'));
    myModal.hide();
  }

  deleteModel(id: number) {
    console.log(`Delete method called for model id: ${id}`);
    this.adminServiceService.removeLLM(id).subscribe(() => this.getAllLLMS(),
  error => this.getAllLLMS());
  }

  toggleEnableDisable(id: number): void {
    console.log("Toggle log");
    
    const model = this.llmModels.find(m => m.id === id);
    if (model) {
      this.adminServiceService.enableDisableLLM(id, !model.enabled).subscribe(() => this.getAllLLMS());
    }
  }

  editModelDetails(index: number): void {
    this.editModelIndex = index;
    this.editModel = { ...this.llmModels[index] };
    this.modalTitle = "Modify LLM Config";
    this.editModal = new bootstrap.Modal(document.getElementById('editModelModal'));
    this.editModal.show();
  }

  formatKey(key: string): string {
    const visiblePart = key.substring(0, 4);
    const maskedPart = '*'.repeat(key.length - 4);
    return visiblePart + maskedPart;
  }

  saveChanges(): void {    
  
  
    if (this.editModelIndex !== undefined && this.editModelIndex !== null) {  
      console.log("Updating LLM");
        
      this.adminServiceService.updateLLM(this.editModel.id, this.editModel.name, this.editModel.endpoint, this.editModel.key).subscribe(() => this.getAllLLMS());
    } else {    
      console.log("adding llm");
      this.adminServiceService.addLLM(this.editModel.name, this.editModel.endpoint, this.editModel.key).subscribe(() => this.getAllLLMS());
    }    
    this.editModal.hide();    
  } 


  getAllLLMS() {
    this.isLoading = true;
    this.adminServiceService.getLLMList().subscribe(response => {
      this.llmModels = response;
    }, error => {
      console.error("Error occurred while fetching LLMs:", error);
    }, () => {
      this.isLoading = false;
    });
  }
  
  // getAllLLMS() {
  //   this.isLoading=true;
  //   this.adminServiceService.getLLMList().subscribe(response => {
  //     this.llmModels = response;
    
  //   });
  //   this.isLoading=false;
  // }
}
