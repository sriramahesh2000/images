import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LLMControlsComponent } from './llmcontrols.component';

describe('LLMControlsComponent', () => {
  let component: LLMControlsComponent;
  let fixture: ComponentFixture<LLMControlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LLMControlsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LLMControlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
