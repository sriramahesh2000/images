// import { Component, OnInit } from '@angular/core';
// import * as am4core from "@amcharts/amcharts4/core";  
// import * as am4maps from "@amcharts/amcharts4/maps";  
// import am4geodata_worldLow from "@amcharts/amcharts4-geodata/worldLow";  
// import am4themes_animated from "@amcharts/amcharts4/themes/animated";  

// @Component({
//   selector: 'app-worldview',
//   templateUrl: './worldview.component.html',
//   styleUrls: ['./worldview.component.css']
// })
// export class WorldviewComponent implements OnInit {

//   constructor() { }
//   private chart !: am4maps.MapChart;

//   ngOnInit(): void {
//   }

//   ngAfterViewInit() {  
//     let dummyData = [  
//       { "id": "US", "name": "United States", "value": 100, "color": am4core.color("#FF0000") },  
//       { "id": "CA", "name": "Canada", "value": 200, "color": am4core.color("#00FF00") },  
//       { "id": "MX", "name": "Mexico", "value": 300, "color": am4core.color("#0000FF") }  
//     ];  
//     this.chart = am4core.create("chartdiv",am4maps.MapChart);
//     this.chart.geodata = am4geodata_worldLow;
//     this.chart.projection = new am4maps.projections.Orthographic();
    
//     let polygonSeries = this.chart.series.push(new am4maps.MapPolygonSeries());  
//     polygonSeries.exclude = ['AQ'];  
//     polygonSeries.useGeodata = true;  
//     polygonSeries.data = dummyData;  // Set the dummy data for your series  
    
//     let polygonTemplate = polygonSeries.mapPolygons.template;  
//     polygonTemplate.fill = am4core.color("#4b0082");  // Default color for all other countries 
//     polygonTemplate.propertyFields.fill = "color"; // if color defined in data  
//     polygonTemplate.tooltipText = "{name}: {value}";  // Display the country name and value from your data  
//     polygonTemplate.polygon.fillOpacity = 0.6;  
    
//     let hs = polygonTemplate.states.create('hover');  
//     hs.properties.fill = am4core.color('blue');  
//     this.chart.logo.disabled = true;
//   }  

//   ngOnDestroy(){
//     if(this.chart){
//         this.chart.dispose();
//     }
//       }

// }



// import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';  
// import * as am4core from "@amcharts/amcharts4/core";  
// import * as am4maps from "@amcharts/amcharts4/maps";  
// import am4geodata_worldLow from "@amcharts/amcharts4-geodata/worldLow";  
// import am4themes_animated from "@amcharts/amcharts4/themes/animated";  
  
// am4core.useTheme(am4themes_animated);  
  
// @Component({  
//   selector: 'app-worldview',  
//   templateUrl: './worldview.component.html',  
//   styleUrls: ['./worldview.component.css']  
// })  
// export class WorldviewComponent implements OnInit, OnDestroy {  
//   private chart!: am4maps.MapChart;  
  
//   constructor(private zone: NgZone) { }  
  
//   ngOnInit() {  
//   }  
  
//   ngAfterViewInit() {  
//     this.zone.runOutsideAngular(() => {  
//       let dummyData = [  
//               { "id": "US", "name": "United States", "value": 100, "color": am4core.color("#FF0000") },  
//               { "id": "CA", "name": "Canada", "value": 200, "color": am4core.color("#00FF00") },  
//               { "id": "MX", "name": "Mexico", "value": 300, "color": am4core.color("#0000FF") }  
//             ];  
//       let chart = am4core.create("chartdiv", am4maps.MapChart);  
//       chart.geodata = am4geodata_worldLow;  
//       chart.projection = new am4maps.projections.Orthographic();  
//       chart.panBehavior = "rotateLongLat";  
//       chart.deltaLatitude = -20;  
//       chart.padding(20, 20, 20, 20);  
  
//       // Create map polygon series  
//       let polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());  
//       polygonSeries.useGeodata = true;  
  
//       // Exclude Antarctica  
//       polygonSeries.exclude = ["AQ"];  
  
//       // Configure series  
//       let polygonTemplate = polygonSeries.mapPolygons.template;  
//       polygonSeries.data = dummyData; 
//       polygonTemplate.tooltipText = "{name}";  
//       polygonTemplate.fill = am4core.color("#4b0082");
//       polygonTemplate.fill = chart.colors.getIndex(0);  
//       polygonTemplate.stroke = new am4core.InterfaceColorSet().getFor("background");  
  
//       // Create hover state and set alternative fill color  
//       let hs = polygonTemplate.states.create("hover");  
//       hs.properties.fill = chart.colors.getIndex(0).brighten(-0.5);  
  
//       chart.homeGeoPoint = { longitude: 0, latitude: -90 };  
//       chart.homeZoomLevel = 1;  
//       chart.zoomControl = new am4maps.ZoomControl();  
//       chart.zoomControl.align = "right";  
//       chart.zoomControl.marginRight = 20;  
//       chart.zoomControl.valign = "middle";  
      
//       this.chart = chart;  
//       this.chart.logo.disabled = true;
//     });  
//   }  
  
//   ngOnDestroy() {  
//     this.zone.runOutsideAngular(() => {  
//       if(this.chart) {  
//         this.chart.dispose();  
//       }  
//     });  
//   }  
// }  


// import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';  
// import * as am4core from "@amcharts/amcharts4/core";  
// import * as am4maps from "@amcharts/amcharts4/maps";  
// import am4geodata_worldLow from "@amcharts/amcharts4-geodata/worldLow";  
// import am4themes_animated from "@amcharts/amcharts4/themes/animated";  
  
// am4core.useTheme(am4themes_animated);  
  
// @Component({  
//   selector: 'app-worldview',  
//   templateUrl: './worldview.component.html',  
//   styleUrls: ['./worldview.component.css']  
// })  
// export class WorldviewComponent implements OnInit, OnDestroy {  
//   private chart!: am4maps.MapChart;  
  
//   constructor(private zone: NgZone) { }  
  
//   ngOnInit() {  
//   }  
  
//   ngAfterViewInit() {  
//     this.zone.runOutsideAngular(() => {  
//       let dummyData = [    
//         { "id": "US", "name": "United States", "value": 100, "color": am4core.color("#FF0000") },    
//         { "id": "CA", "name": "Canada", "value": 200, "color": am4core.color("#00FF00") },    
//         { "id": "MX", "name": "Mexico", "value": 300, "color": am4core.color("#0000FF") }    
//       ];  
  
//       let chart = am4core.create("chartdiv", am4maps.MapChart);  
//       chart.geodata = am4geodata_worldLow;  
//       chart.projection = new am4maps.projections.Orthographic();  
//       chart.panBehavior = "rotateLongLat";  
//       chart.deltaLatitude = -20;  
//       chart.padding(20, 20, 20, 20);  
  
//       // Create map polygon series  
//       let polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());  
//       polygonSeries.useGeodata = true;  
//       polygonSeries.data = dummyData;  
  
//       // Exclude Antarctica  
//       polygonSeries.exclude = ["AQ"];  
  
//       // Configure series  
//       let polygonTemplate = polygonSeries.mapPolygons.template;  
//       polygonTemplate.tooltipText = "{name}";  
//       polygonTemplate.propertyFields.fill = "color";  
  
//       // Create hover state and set alternative fill color  
//       let hs = polygonTemplate.states.create("hover");  
//       hs.properties.fill = am4core.color("#3c5bdc");  
  
//       chart.homeGeoPoint = { longitude: 0, latitude: -90 };  
//       chart.homeZoomLevel = 1;  
//       chart.zoomControl = new am4maps.ZoomControl();  
//       chart.zoomControl.align = "right";  
//       chart.zoomControl.marginRight = 20;  
//       chart.zoomControl.valign = "middle";  
  
//       this.chart = chart;  
//     });  
//   }  
  
//   ngOnDestroy() {  
//     this.zone.runOutsideAngular(() => {  
//       if(this.chart) {  
//         this.chart.dispose();  
//       }  
//     });  
//   }  
// }  



// import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';  
// import * as am4core from "@amcharts/amcharts4/core";  
// import * as am4maps from "@amcharts/amcharts4/maps";  
// import am4geodata_worldLow from "@amcharts/amcharts4-geodata/worldLow";  
// import am4themes_animated from "@amcharts/amcharts4/themes/animated";  
  
// am4core.useTheme(am4themes_animated);  
  
// @Component({  
//   selector: 'app-worldview',  
//   templateUrl: './worldview.component.html',  
//   styleUrls: ['./worldview.component.css']  
// })  
// export class WorldviewComponent implements OnInit, OnDestroy {  
//   private chart!: am4maps.MapChart;  
  
//   constructor(private zone: NgZone) { }  
  
//   ngOnInit() {  
//   }  
  
//   ngAfterViewInit() {  
//     this.zone.runOutsideAngular(() => {  
//       let dummyData = [    
//         { "id": "US", "name": "United States", "value": 100, "color": am4core.color("#FF0000") },    
//         { "id": "CA", "name": "Canada", "value": 200, "color": am4core.color("#00FF00") },    
//         { "id": "MX", "name": "Mexico", "value": 300, "color": am4core.color("#0000FF") }    
//       ];  
  
//       let chart = am4core.create("chartdiv", am4maps.MapChart);  
//       chart.geodata = am4geodata_worldLow;  
//       chart.projection = new am4maps.projections.Orthographic();  
//       chart.panBehavior = "rotateLongLat";  
//       chart.deltaLatitude = -20;  
//       chart.padding(20, 20, 20, 20);  
  
//       // Create map polygon series  
//       let polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());  
//       polygonSeries.useGeodata = true;  
//       polygonSeries.data = dummyData;  
  
//       // Exclude Antarctica  
//       polygonSeries.exclude = ["AQ"];  
  
//       // Configure series  
//       let polygonTemplate = polygonSeries.mapPolygons.template;  
//       polygonTemplate.tooltipText = "{name}";  
//       polygonTemplate.propertyFields.fill = "color";  
  
//       // Create hover state and set alternative fill color  
//       let hs = polygonTemplate.states.create("hover");  
//       hs.properties.fill = am4core.color("#3c5bdc");  
  
//       // Set homeGeoPoint to India  
//       chart.homeGeoPoint = { longitude: 78.9629, latitude: 20.5937 };  
//       chart.homeZoomLevel = 1.5;  
//       chart.zoomControl = new am4maps.ZoomControl();  
//       chart.zoomControl.align = "right";  
//       chart.zoomControl.marginRight = 20;  
//       chart.zoomControl.valign = "middle";  
  
//       this.chart = chart;  
//     });  
//   }  
  
//   ngOnDestroy() {  
//     this.zone.runOutsideAngular(() => {  
//       if(this.chart) {  
//         this.chart.dispose();  
//       }  
//     });  
//   }  
// }  









// import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';  
// import * as am4core from "@amcharts/amcharts4/core";  
// import * as am4maps from "@amcharts/amcharts4/maps";  
// import am4geodata_worldLow from "@amcharts/amcharts4-geodata/worldLow";  
// import am4themes_animated from "@amcharts/amcharts4/themes/animated";  
  
// am4core.useTheme(am4themes_animated);  
  
// @Component({  
//   selector: 'app-worldview',  
//   templateUrl: './worldview.component.html',  
//   styleUrls: ['./worldview.component.css']  
// })  
// export class WorldviewComponent implements OnInit, OnDestroy {  
//   private chart!: am4maps.MapChart;  
  
//   constructor(private zone: NgZone) { }  
  
//   ngOnInit() {  
//   }  
  
//   ngAfterViewInit() {  
//     this.zone.runOutsideAngular(() => {  
//       let dummyData = [    
//         { "id": "US", "name": "United States", "value": 100, "color": am4core.color("#FF0000") },    
//         { "id": "CA", "name": "Canada", "value": 200, "color": am4core.color("#00FF00") },    
//         { "id": "MX", "name": "Mexico", "value": 300, "color": am4core.color("#0000FF") }    
//       ];  
  
//       let chart = am4core.create("chartdiv", am4maps.MapChart);  
//       chart.geodata = am4geodata_worldLow;  
//       chart.projection = new am4maps.projections.Orthographic();  
//       chart.panBehavior = "rotateLongLat";  
//       chart.deltaLatitude = -20;  
//       chart.padding(20, 20, 20, 20);  
  
//       // Create map polygon series  
//       let polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());  
//       polygonSeries.useGeodata = true;  
//       polygonSeries.data = dummyData;  
  
//       // Exclude Antarctica  
//       polygonSeries.exclude = ["AQ"];  
  
//       // Configure series  
//       let polygonTemplate = polygonSeries.mapPolygons.template;  
//       polygonTemplate.tooltipText = "{name}: {value}";  
//       polygonTemplate.propertyFields.fill = "color";  
  
//       // Create hover state and set alternative fill color  
//       let hs = polygonTemplate.states.create("hover");  
//       hs.properties.fill = am4core.color("#3c5bdc");  
  
//       // Set homeGeoPoint to India  
//       chart.homeGeoPoint = { longitude: 78.9629, latitude: 20.5937 };  
//       chart.homeZoomLevel = 2.5;  
//       chart.zoomControl = new am4maps.ZoomControl();  
//       chart.zoomControl.align = "right";  
//       chart.zoomControl.marginRight = 20;  
//       chart.zoomControl.valign = "middle";  
  
//       this.chart = chart;  
//     });  
//   }  
  
//   ngOnDestroy() {  
//     this.zone.runOutsideAngular(() => {  
//       if(this.chart) {  
//         this.chart.dispose();  
//       }  
//     });  
//   }  
// }  




import { Component, OnInit, OnDestroy, NgZone, ChangeDetectorRef, ElementRef, ViewChild } from '@angular/core';    
import * as am4core from "@amcharts/amcharts4/core";    
import * as am4maps from "@amcharts/amcharts4/maps";    
import am4geodata_worldLow from "@amcharts/amcharts4-geodata/worldLow";    
import am4themes_animated from "@amcharts/amcharts4/themes/animated";    
import {FormControl} from '@angular/forms';
import {  FormBuilder } from '@angular/forms';  
am4core.useTheme(am4themes_animated);    
    
@Component({    
  selector: 'app-worldview',    
  templateUrl: './worldview.component.html',    
  styleUrls: ['./worldview.component.css']    
})    
export class WorldviewComponent implements OnInit, OnDestroy {    
  private chart?: am4maps.MapChart;    
  range = new FormControl();  
  @ViewChild('chartDiv', { static: false }) chartDiv!: ElementRef;  

  constructor(private zone: NgZone, private cdRef : ChangeDetectorRef) { }    
    
  ngOnInit() {    
  }    
    
  ngAfterViewInit() {    
    this.zone.runOutsideAngular(() => {    
      let dummyData = [      
        { "id": "US", "name": "United States", "value": 100, "color": am4core.color("#4a68d9") },      
        { "id": "CA", "name": "Canada", "value": 200, "color": am4core.color("#98a3f6") },      
        { "id": "MX", "name": "Mexico", "value": 300, "color": am4core.color("#4a68d9") }      
      ];    
    
      // let chart = am4core.create("chartdiv", am4maps.MapChart); 
      let chart = am4core.create(this.chartDiv.nativeElement, am4maps.MapChart);  
   
      chart.geodata = am4geodata_worldLow;    
      chart.projection = new am4maps.projections.Orthographic();    
      chart.panBehavior = "rotateLongLat";    
      chart.deltaLatitude = -20;    
      chart.padding(20, 20, 20, 20);    
    
      // Create map polygon series    
      let polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());    
      polygonSeries.useGeodata = true;    
      polygonSeries.data = dummyData;    
    
      // Exclude Antarctica    
      // polygonSeries.exclude = ["AQ"];    
    
      // Configure series    
      let polygonTemplate = polygonSeries.mapPolygons.template;    
      polygonTemplate.tooltipText = "{name}: {value}";    
      polygonTemplate.propertyFields.fill = "color";    
    
      // Create hover state and set alternative fill color    
      let hs = polygonTemplate.states.create("hover");    
      hs.properties.fill = am4core.color("#3c5bdc");    
      polygonTemplate.fill = am4core.color("#4b0082");  
      chart.backgroundSeries.mapPolygons.template.polygon.fill = am4core.color("#0000FF");  
      chart.homeGeoPoint = { longitude: 0, latitude: 0};      
      chart.homeZoomLevel = 0;    
      // Set homeGeoPoint to India    
      // chart.homeGeoPoint = { longitude: 78.9629, latitude: 20.5937 };    
      // chart.homeZoomLevel = 2.5;    
      chart.zoomControl = new am4maps.ZoomControl();    
      chart.zoomControl.align = "right";    
      chart.zoomControl.marginRight = 20; 
      chart.homeZoomLevel = 0.72;   
      chart.zoomControl.valign = "middle";    
      chart.logo.disabled = true;
      this.chart = chart;    
    });    
    this.cdRef.detectChanges();    
  }    
    
  ngOnDestroy() {    
    this.zone.runOutsideAngular(() => {    
      if(this.chart) {    
        this.chart.dispose();   
        this.chart=undefined; 
      }    
    });    
  }    
}    
