import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';

@Component({
  selector: 'app-chat-doc',
  templateUrl: './chat-doc.component.html',
  styleUrls: ['./chat-doc.component.css']
})
export class ChatDocComponent implements OnInit, OnDestroy, AfterViewInit {
  fileName: string='';
currentFileName(fileName: string) {
  localStorage.setItem('fileName', fileName);
  this.fileName = fileName;
}
  isUploading: boolean = false;
  uploadedFiles: File[] = [];

  constructor(private conHistService: ConHistService) { }
selectedDoc:any
 
  ngAfterViewInit(): void {
    this.conHistService.retrieveDoc().subscribe(
      response => {
        console.log(JSON.stringify(response));
        response.forEach(fileData => {
          const blob = new Blob([''], { type: 'text/plain' });
          console.log("Doc name: " + fileData.udoc_path);
          const file = new File([blob], fileData.udoc_path, { type: 'text/plain' });
          this.uploadedFiles.push(file);
        });
        // Set localStorage with the filename of the file at index 0
        if (this.uploadedFiles.length > 0) {
          localStorage.setItem('fileName', this.uploadedFiles[0].name);
          this.fileName = this.uploadedFiles[0].name;
        }
      }
    );
  }

  ngOnInit(): void {
    localStorage.setItem('RAGFromDoc', 'True');
  }

  ngOnDestroy(): void {
    localStorage.setItem('RAGFromDoc', 'False');
  }

  private extractDocumentName(udocPath: string): string {
    const parts = udocPath.split('\\');
    return parts[parts.length - 1];
  }

  onDrop($event: DragEvent) {
    $event.preventDefault();
    if ($event.dataTransfer) {
      this.uploadFiles($event.dataTransfer.files);
    }
  }

  onDragOver($event: DragEvent) {
    $event.stopPropagation();
    $event.preventDefault();
  }

  onFileSelected($event: Event) {
    const fileInput = $event.target as HTMLInputElement;
    if (fileInput.files) {
      this.uploadFiles(fileInput.files);
    }
  }

  uploadFiles(files: FileList) {
    const formData = new FormData();
    const newFiles: File[] = [];

    for (let i = 0; i < files.length; i++) {
        const file = files.item(i);
        if (file && file.type === 'application/pdf') {
            const isFileAlreadyUploaded = this.uploadedFiles.some(uploadedFile => uploadedFile.name === file.name);
            if (!isFileAlreadyUploaded) {
                // Check constraints for PDF name
                if (/^[a-zA-Z0-9][a-zA-Z0-9-]{0,126}[a-zA-Z0-9]\.[a-zA-Z0-9]+$/
                .test(file.name) && file.name.length <= 128) {
                    formData.append('document', file, file.name);
                    console.log("Form data: " + JSON.stringify(formData));

                    newFiles.push(file);
                } else {
                    alert('PDF file name must only contain letters (upper or lower case), digits, or dashes, cannot start or end with dashes, and is limited to 128 characters');
                    return;
                }
            }
        } else if (file) {
            alert('Only PDF files are allowed');
            return;
        }
    }

    if (newFiles.length > 0) {
        this.isUploading = true;
        this.conHistService.uploadDoc(formData).subscribe(
            response => {
                localStorage.setItem("docUploadedID", response.id.toString());
                console.log("Files Uploaded: " + response.email_id);
                this.uploadedFiles.push(...newFiles);
                this.isUploading = false;
            },
            error => {
                console.log('Error uploading files:', error);
                alert('Error uploading files. Please try again later.');
                this.isUploading = false;
            }
        );
    } else {
        alert('The file is already present');
    }
    if (this.uploadedFiles.length > 0) {
      localStorage.setItem('fileName', this.uploadedFiles[0].name);
      this.fileName = this.uploadedFiles[0].name;
      
    }
}


  deleteFile(index: number) {
  //   const deletedDocId = this.uploadedFiles[index].id; 
  // localStorage.setItem('deletedDocId', deletedDocId.toString());
    this.uploadedFiles.splice(index, 1);
    this.conHistService.deleteDoc();
    localStorage.removeItem('fileName')
  }
}


