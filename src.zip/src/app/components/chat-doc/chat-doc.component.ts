import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { ConHistService } from 'src/app/services/convHist/con-hist.service';

interface UploadedFile {
  file: File;
  documentId: number;
}

@Component({
  selector: 'app-chat-doc',
  templateUrl: './chat-doc.component.html',
  styleUrls: ['./chat-doc.component.css']
})
export class ChatDocComponent implements OnInit, OnDestroy, AfterViewInit {
  fileName: string = '';
  isUploading: boolean = false;
  uploadedFiles: UploadedFile[] = [];

  constructor(private conHistService: ConHistService) { }

  currentFileName(fileName: string) {
    localStorage.setItem('fileName', fileName);
    this.fileName = fileName;
  }

  ngAfterViewInit(): void {
    this.conHistService.retrieveDoc().subscribe(
      response => {
        console.log(JSON.stringify(response));
        response.forEach(fileData => {
          console.log("fileData: "+ JSON.stringify(fileData));
          
          const blob = new Blob([''], { type: 'text/plain' });
          console.log("Doc name: " + fileData.udoc_path);
          const file = new File([blob], fileData.udoc_path, { type: 'text/plain' });
          console.log("Doc Ids:  "+fileData.id);
          
          this.uploadedFiles.push({ file: file, documentId: fileData.id });
        });
        // Set localStorage with the filename of the file at index 0
        if (this.uploadedFiles.length > 0) {
          localStorage.setItem('fileName', this.uploadedFiles[0].file.name);
          this.fileName = this.uploadedFiles[0].file.name;
        }
      }
    );
  }

  ngOnInit(): void {
    localStorage.setItem('RAGFromDoc', 'True');
  }

  ngOnDestroy(): void {
    localStorage.setItem('RAGFromDoc', 'False');
  }
  
  onDrop($event: DragEvent) {
    $event.preventDefault();
    if (!this.isUploading && $event.dataTransfer) {
      this.uploadFiles($event.dataTransfer.files);
    }
  }

  onDragOver($event: DragEvent) {
    $event.stopPropagation();
    $event.preventDefault();
  }


  onFileSelected($event: Event) {
    const fileInput = $event.target as HTMLInputElement;
    if (!this.isUploading && fileInput.files) {
      this.uploadFiles(fileInput.files);
    }
  }


  // uploadFiles(files: FileList) {
  //   const formData = new FormData();
  //   const newFiles: UploadedFile[] = [];
  //   const shouldUpdateLocalStorage = this.uploadedFiles.length === 0; // Check if there are no documents available
  
  //   for (let i = 0; i < files.length; i++) {
  //     const file = files.item(i);
  //     if (file && file.type === 'application/pdf') {
  //       const isFileAlreadyUploaded = this.uploadedFiles.some(uploadedFile => uploadedFile.file.name === file.name);
  //       if (!isFileAlreadyUploaded) {
  //         // Check constraints for PDF name
  //         let fileName = file.name;
  //         if (!/^[a-zA-Z0-9][a-zA-Z0-9-]{0,126}[a-zA-Z0-9]\.[a-zA-Z0-9]+$/.test(fileName) || fileName.length > 128) {
  //           // Modify the filename to conform to the regex
  //           const baseName = fileName.replace(/[^a-zA-Z0-9]/g, '').substring(0, 126);
  //           const extension = fileName.split('.').pop();
  //           fileName = `${baseName}.${extension}`;
  //           console.log("***************: "+fileName);
            
  //           // Ensure the filename doesn't end with a dash and is not too long
  //           if (fileName.endsWith('-')) {
  //             fileName = fileName.slice(0, -1) + '1';
  //           }
  //           if (fileName.length > 128) {
  //             fileName = fileName.substring(0, 127) + '1';
  //           }
  //         }
  
  //         // Create a new file with the modified name
  //         const newFile = new File([file], fileName, { type: file.type });
  
  //         formData.append('document', newFile, newFile.name);
  //         console.log("Form data: " + JSON.stringify(formData));
  //         // Dummy documentId, replace with actual id from the response
  //         newFiles.push({ file: newFile, documentId: Math.floor(Math.random() * 1000) });
  //       }
  //     } else if (file) {
  //       alert('Only PDF files are allowed');
  //       return;
  //     }
  //   }
  
  //   if (newFiles.length > 0) {
  //     this.isUploading = true;
  //     this.conHistService.uploadDoc(formData).subscribe(
  //       response => {
  //         localStorage.setItem("docUploadedID", response.id.toString());
  //         console.log("Files Uploaded: " + response.email_id);
  //         this.uploadedFiles.push(...newFiles);
  //         this.isUploading = false;
  
  //         if (shouldUpdateLocalStorage) {
  //           localStorage.setItem('fileName', newFiles[0].file.name);
  //           this.fileName = newFiles[0].file.name;
  //         }
  //       },
  //       error => {
  //         console.log('Error uploading files:', error);
  //         alert('Error uploading files. Please try again later.');
  //         this.isUploading = false;
  //       }
  //     );
  //   } else {
  //     alert('The file is already present');
  //   }
  // }
  
  uploadFiles(files: FileList) {
    const formData = new FormData();
    const newFiles: UploadedFile[] = [];
    const shouldUpdateLocalStorage = this.uploadedFiles.length === 0;

    for (let i = 0; i < files.length; i++) {
      const file = files.item(i);
      if (file && file.type === 'application/pdf') {
        const isFileAlreadyUploaded = this.uploadedFiles.some(uploadedFile => uploadedFile.file.name === file.name);
        if (!isFileAlreadyUploaded) {
          let fileName = file.name;
          if (!/^[a-zA-Z0-9][a-zA-Z0-9-]{0,126}[a-zA-Z0-9]\.[a-zA-Z0-9]+$/.test(fileName) || fileName.length > 128) {
            const baseName = fileName.replace(/[^a-zA-Z0-9]/g, '').substring(0, 126);
            const extension = fileName.split('.').pop();
            fileName = `${baseName}.${extension}`;
            if (fileName.endsWith('-')) {
              fileName = fileName.slice(0, -1) + '1';
            }
            if (fileName.length > 128) {
              fileName = fileName.substring(0, 127) + '1';
            }
          }

          const newFile = new File([file], fileName, { type: file.type });
          formData.append('document', newFile, newFile.name);
          newFiles.push({ file: newFile, documentId: Math.floor(Math.random() * 1000) });
        }
      } else if (file) {
        alert('Only PDF files are allowed');
        return;
      }
    }

    if (newFiles.length > 0) {
      this.isUploading = true;
      this.conHistService.uploadDoc(formData).subscribe(
        response => {
          localStorage.setItem("docUploadedID", response.id.toString());
          this.uploadedFiles.push(...newFiles);
          this.isUploading = false;
          if (shouldUpdateLocalStorage) {
            localStorage.setItem('fileName', newFiles[0].file.name);
            this.fileName = newFiles[0].file.name;
          }
        },
        error => {
          console.log('Error uploading files:', error);
          alert('Error uploading file. Please try again later.');
          this.isUploading = false;
        }
      );
    } else {
      alert('The file is already present');
    }
  }

  

  deleteFile(index: number) {
    const documentId = this.uploadedFiles[index].documentId;
    console.log("Document to be deleted: "+ documentId);
    
    localStorage.setItem('docUploadedID', documentId.toString());
    this.uploadedFiles.splice(index, 1);
    this.conHistService.deleteDoc();

    if (this.uploadedFiles.length > 0) {
      localStorage.setItem('fileName', this.uploadedFiles[0].file.name);
      this.fileName = this.uploadedFiles[0].file.name;
    } else {
      localStorage.removeItem('fileName');
      this.fileName = '';
    }
  }

  // deleteFile(index: number) {
  //   const documentId = this.uploadedFiles[index].documentId; // Get the documentId of the file to be deleted
  //   localStorage.setItem('docUploadedID', documentId.toString()); // Store the documentId in localStorage

  //   this.uploadedFiles.splice(index, 1);
  //   this.conHistService.deleteDoc();
  //   localStorage.removeItem('fileName');
  // }
}





